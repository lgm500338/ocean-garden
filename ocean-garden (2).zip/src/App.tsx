import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import {
  BallColor,
  TubeData,
  ThemeType,
  CraftedGem,
  GameHistoryState,
  HintMove,
  Language,
} from './types';
import { INITIAL_LEVELS, INITIAL_GEMS, generateProceduralLevel } from './levels';
import { sound } from './audio';
import { findSmartHint, findSolverHint } from './solver';
import { TestTube } from './components/TestTube';
import { JewelVaultModal } from './components/JewelVaultModal';
import { VictoryModal } from './components/VictoryModal';
import { DynamicBackground } from './components/DynamicBackground';
import { getTranslation } from './i18n';
import {
  RotateCcw,
  Undo2,
  PlusCircle,
  Lightbulb,
  Volume2,
  VolumeX,
  Music,
  ChevronLeft,
  ChevronRight,
  Info,
  Waves,
  Globe,
} from 'lucide-react';

export default function App() {
  const [lang, setLang] = useState<Language>('ko');
  const t = getTranslation(lang);

  const [maxUnlockedLevel, setMaxUnlockedLevel] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('ocean_garden_max_level');
      return saved ? parseInt(saved, 10) : 0;
    } catch {
      return 0;
    }
  });

  const [levelIdx, setLevelIdx] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('ocean_garden_current_level');
      return saved ? parseInt(saved, 10) : 0;
    } catch {
      return 0;
    }
  });

  const victoryTimerRef = useRef<NodeJS.Timeout | null>(null);
  
  // Dynamic or hand-crafted level config
  const currentLevelConfig = useMemo(
    () =>
      levelIdx < INITIAL_LEVELS.length
        ? INITIAL_LEVELS[levelIdx]
        : generateProceduralLevel(levelIdx + 1),
    [levelIdx]
  );

  const [tubes, setTubes] = useState<TubeData[]>([]);
  const [selectedTubeIdx, setSelectedTubeIdx] = useState<number | null>(null);
  const [moves, setMoves] = useState<number>(0);
  const [history, setHistory] = useState<GameHistoryState[]>([]);
  const [theme] = useState<ThemeType>('aqua');
  const [extraTubesCount, setExtraTubesCount] = useState<number>(0);
  const [shakingTubeIdx, setShakingTubeIdx] = useState<number | null>(null);

  // Smart Hint state
  const [activeHint, setActiveHint] = useState<HintMove | null>(null);
  const [hintMessage, setHintMessage] = useState<string | null>(null);
  const [remainingHints, setRemainingHints] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('ocean_garden_hints');
      const n = saved === null ? 5 : parseInt(saved, 10);
      return Number.isFinite(n) ? n : 5;
    } catch {
      return 5;
    }
  });
  const [earnedPearls, setEarnedPearls] = useState<number>(0);

  useEffect(() => {
    try {
      localStorage.setItem('ocean_garden_hints', String(remainingHints));
    } catch {}
  }, [remainingHints]);

  // Audio States
  const [isBgmOn, setIsBgmOn] = useState<boolean>(true);
  const [isSfxOn, setIsSfxOn] = useState<boolean>(true);

  const [craftedGems, setCraftedGems] = useState<CraftedGem[]>(() => {
    try {
      const saved = localStorage.getItem('ocean_garden_gems');
      return saved ? JSON.parse(saved) : INITIAL_GEMS;
    } catch {
      return INITIAL_GEMS;
    }
  });

  const [showVault, setShowVault] = useState<boolean>(false);
  const [showVictory, setShowVictory] = useState<boolean>(false);
  const [newGemsEarned, setNewGemsEarned] = useState<CraftedGem[]>([]);
  const [showHelpGuide, setShowHelpGuide] = useState<boolean>(false);

  const mainContainerRef = useRef<HTMLDivElement | null>(null);

  // Initialize level
  const initLevel = useCallback((lvlIndex: number) => {
    if (victoryTimerRef.current) {
      clearTimeout(victoryTimerRef.current);
      victoryTimerRef.current = null;
    }

    const config =
      lvlIndex < INITIAL_LEVELS.length
        ? INITIAL_LEVELS[lvlIndex]
        : generateProceduralLevel(lvlIndex + 1);

    const newTubes: TubeData[] = config.tubes.map((tubeColors, idx) => {
      const isDone =
        tubeColors.length === config.tubeCapacity &&
        tubeColors.every((c) => c === tubeColors[0]);
      return {
        id: idx,
        balls: tubeColors.map((color, bIdx) => ({
          id: `${lvlIndex}-${idx}-${bIdx}-${color}`,
          color: color as BallColor,
        })),
        isCompleted: isDone,
        isRefining: false,
        isSealed: isDone,
      };
    });

    setTubes(newTubes);
    setSelectedTubeIdx(null);
    setMoves(0);
    setHistory([]);
    setExtraTubesCount(0);
    setNewGemsEarned([]);
    setEarnedPearls(0);
    setActiveHint(null);
    setHintMessage(null);
    setShowVictory(false);
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('ocean_garden_current_level', String(levelIdx));
    } catch {}
    initLevel(levelIdx);
  }, [levelIdx, initLevel]);

  // Save gems
  useEffect(() => {
    try {
      localStorage.setItem('ocean_garden_gems', JSON.stringify(craftedGems));
    } catch {
      // Safe fallback
    }
  }, [craftedGems]);

  const checkTubeCompletion = (balls: TubeData['balls'], capacity: number) => {
    if (balls.length !== capacity) return false;
    const firstColor = balls[0].color;
    return balls.every((b) => b.color === firstColor);
  };

  const checkLevelVictory = (currentTubes: TubeData[], capacity: number) => {
    return currentTubes.every((t) => {
      if (t.balls.length === 0) return true;
      return checkTubeCompletion(t.balls, capacity);
    });
  };

  const registerCraftedGem = (color: BallColor) => {
    setCraftedGems((prev) => {
      const idx = prev.findIndex((g) => g.color === color);
      if (idx !== -1) {
        const next = [...prev];
        next[idx] = { ...next[idx], count: next[idx].count + 1 };
        return next;
      }
      return prev;
    });
  };

  // Tube click handler
  const handleTubeClick = (tubeIdx: number) => {
    sound.unlockAudio();
    const capacity = currentLevelConfig.tubeCapacity;

    // Reset active hint on player interaction
    setActiveHint(null);
    setHintMessage(null);

    // 1. If no tube is currently selected
    if (selectedTubeIdx === null) {
      const targetTube = tubes[tubeIdx];
      if (targetTube.isCompleted || targetTube.isSealed || targetTube.balls.length === 0) {
        sound.haptic(8);
        return;
      }
      setSelectedTubeIdx(tubeIdx);
      sound.playBallLift(theme === 'aqua');
      return;
    }

    // 2. If clicking the already selected tube -> Deselect
    if (selectedTubeIdx === tubeIdx) {
      setSelectedTubeIdx(null);
      sound.playBallDrop(0, theme === 'aqua');
      return;
    }

    // 3. Move ball from selectedTubeIdx to tubeIdx
    const sourceTube = tubes[selectedTubeIdx];
    const targetTube = tubes[tubeIdx];

    if (targetTube.isCompleted || targetTube.isSealed) {
      setShakingTubeIdx(tubeIdx);
      setTimeout(() => setShakingTubeIdx(null), 350);
      sound.haptic(20);
      return;
    }

    if (sourceTube.isCompleted || sourceTube.isSealed || sourceTube.balls.length === 0) {
      setSelectedTubeIdx(null);
      return;
    }

    const movingBall = sourceTube.balls[sourceTube.balls.length - 1];
    
    // Check if target can receive the moving ball
    const hasSpace = targetTube.balls.length < capacity;
    const isSameColor =
      targetTube.balls.length > 0 &&
      targetTube.balls[targetTube.balls.length - 1].color === movingBall.color;
    const canMove = hasSpace && (targetTube.balls.length === 0 || isSameColor);

    // If valid move: execute move synchronously with ZERO ghost timeouts!
    if (canMove) {
      // Record History State for Undo
      setHistory((prev) => [
        ...prev,
        {
          tubes: tubes.map((t) => ({ ...t, balls: [...t.balls] })),
          moves,
        },
      ]);

      // Perform move and strictly calculate pure completion
      const updatedTubes = tubes.map((t, idx) => {
        if (idx === selectedTubeIdx) {
          const remainingBalls = t.balls.slice(0, -1);
          const isDone =
            remainingBalls.length === capacity &&
            remainingBalls.every((b) => b.color === remainingBalls[0].color);
          return {
            ...t,
            balls: remainingBalls,
            isCompleted: isDone,
            isSealed: isDone,
            isRefining: false,
          };
        }
        if (idx === tubeIdx) {
          const newBalls = [...t.balls, movingBall];
          const isDone =
            newBalls.length === capacity &&
            newBalls.every((b) => b.color === newBalls[0].color);
          return {
            ...t,
            balls: newBalls,
            isCompleted: isDone,
            isSealed: isDone,
            isRefining: false,
          };
        }
        const isDone =
          t.balls.length === capacity &&
          t.balls.every((b) => b.color === t.balls[0].color);
        return {
          ...t,
          isCompleted: isDone,
          isSealed: isDone,
          isRefining: false,
        };
      });

      setMoves((m) => m + 1);
      setSelectedTubeIdx(null);
      setTubes(updatedTubes);
      sound.playBallDrop(targetTube.balls.length, theme === 'aqua');

      const justCompleted = updatedTubes[tubeIdx].isCompleted && !targetTube.isCompleted;
      if (justCompleted) {
        sound.playCorkPop();
        sound.playGemFusion();
      }

      // Check level victory
      const isLevelWon = checkLevelVictory(updatedTubes, capacity);
      if (isLevelWon) {
        const nextLevel = levelIdx + 1;

        // 보상(진주·힌트)은 그 레벨을 처음 깼을 때만 지급 → 되돌리기/다시하기로 무한 획득 방지
        const isFirstClear = levelIdx >= maxUnlockedLevel;
        if (isFirstClear) {
          const levelColors = Array.from(
            new Set(currentLevelConfig.tubes.flat())
          ) as BallColor[];
          levelColors.forEach((c) => registerCraftedGem(c));
          setNewGemsEarned(
            craftedGems.filter((g) => levelColors.includes(g.color))
          );
          setEarnedPearls(levelColors.length * 10);
          setRemainingHints((h) => h + 1);
        } else {
          setNewGemsEarned([]);
          setEarnedPearls(0);
        }

        setMaxUnlockedLevel((prev) => {
          const updated = Math.max(prev, nextLevel);
          try {
            localStorage.setItem('ocean_garden_max_level', String(updated));
            localStorage.setItem('ocean_garden_current_level', String(nextLevel));
          } catch {}
          return updated;
        });

        if (victoryTimerRef.current) clearTimeout(victoryTimerRef.current);
        victoryTimerRef.current = setTimeout(() => {
          sound.playStageClear();
          setShowVictory(true);
        }, 400);
      }
      return;
    }

    // INVALID MOVE (Target is full, different color, or sealed):
    // 1. Shake target tube with gentle haptic to show it cannot be placed here
    setShakingTubeIdx(tubeIdx);
    setTimeout(() => setShakingTubeIdx(null), 350);
    sound.haptic(25);

    // 2. Return the floating ball safely back into its home tube!
    // Never leave a ball floating in the air on an invalid move!
    setSelectedTubeIdx(null);
    sound.playBallDrop(0, theme === 'aqua');
  };

  // Undo Move
  const handleUndo = () => {
    if (history.length === 0) return;
    sound.unlockAudio();
    sound.haptic(15);
    const lastState = history[history.length - 1];
    setHistory((prev) => prev.slice(0, -1));
    setTubes(lastState.tubes);
    setMoves(lastState.moves);
    setSelectedTubeIdx(null);
    setActiveHint(null);
    setHintMessage(null);
  };

  // Restart Level (항상 동일한 시드로 생성된 바로 그 판을 다시 시작)
  const handleRestart = () => {
    sound.unlockAudio();
    sound.haptic(25);
    initLevel(levelIdx);
  };

  // Add Extra Tube (+1 시험관: 되돌리기를 해도 추가된 시험관이 사라지지 않도록 히스토리 보존)
  const handleAddExtraTube = () => {
    if (extraTubesCount >= 2) return;
    sound.unlockAudio();
    sound.haptic([15, 20]);
    sound.playCorkPop();

    const newEmptyTube: TubeData = {
      id: tubes.length,
      balls: [],
      isCompleted: false,
      isRefining: false,
      isSealed: false,
    };

    setTubes((prev) => [...prev, newEmptyTube]);
    // 기존 히스토리에도 새 빈 시험관을 추가해 되돌리기 시 증발 방지!
    setHistory((prev) =>
      prev.map((h) => ({
        ...h,
        tubes: [...h.tubes, { ...newEmptyTube, balls: [] }],
      }))
    );
    setExtraTubesCount((c) => c + 1);
  };

  // Smart Hint Request
  const handleRequestHint = () => {
    sound.unlockAudio();
    if (remainingHints <= 0) {
      sound.haptic(40);
      setActiveHint(null);
      setHintMessage(t.noHintsLeft);
      return;
    }

    const hint =
      findSolverHint(tubes, currentLevelConfig.tubeCapacity) ??
      findSmartHint(tubes, currentLevelConfig.tubeCapacity);
    if (hint) {
      sound.playHintChime();
      setActiveHint(hint);
      setRemainingHints((h) => Math.max(0, h - 1));
      setHintMessage(
        lang === 'ko'
          ? `💡 #${hint.fromTubeIdx + 1}번 시험관의 바다생물을 #${hint.toTubeIdx + 1}번으로 옮겨보세요!`
          : `💡 Move the creature from #${hint.fromTubeIdx + 1} to #${hint.toTubeIdx + 1}!`
      );
    } else {
      sound.haptic(40);
      setHintMessage(t.noMoreMoves);
    }
  };

  // Audio Toggles
  const toggleBgm = () => {
    sound.unlockAudio();
    const next = !isBgmOn;
    setIsBgmOn(next);
    sound.setBgmMuted(!next);
  };

  const toggleSfx = () => {
    sound.unlockAudio();
    const next = !isSfxOn;
    setIsSfxOn(next);
    sound.setSfxMuted(!next);
  };

  // Total Pearls calculation (Total gems * 10)
  const totalPearls = craftedGems.reduce((sum, g) => sum + g.count * 10, 0);

  // Check if a tube can receive the currently floating ball
  const checkCanReceive = (tubeIdx: number) => {
    if (selectedTubeIdx === null || selectedTubeIdx === tubeIdx) return false;
    const target = tubes[tubeIdx];
    if (target.isCompleted || target.isSealed || target.balls.length >= currentLevelConfig.tubeCapacity) return false;
    const source = tubes[selectedTubeIdx];
    if (source.balls.length === 0) return false;
    const moving = source.balls[source.balls.length - 1];
    return target.balls.length === 0 || target.balls[target.balls.length - 1].color === moving.color;
  };

  // Split tubes into rows if total tubes > 5
  const isMultiRow = tubes.length > 5;
  const halfCount = Math.ceil(tubes.length / 2);
  const row1Tubes = isMultiRow ? tubes.slice(0, halfCount) : tubes;
  const row2Tubes = isMultiRow ? tubes.slice(halfCount) : [];

  return (
    <div
      ref={mainContainerRef}
      onClick={() => sound.unlockAudio()}
      className="min-h-[100dvh] h-[100dvh] w-full flex items-center justify-center p-0 select-none overflow-hidden relative bg-slate-950"
    >
      {/* 1. Dynamic Ocean Background (레벨마다 달라지는 4K 실사 바다) */}
      <DynamicBackground theme={theme} levelNumber={levelIdx + 1} />

      {/* 2. Main Game Container */}
      <div
        className="relative z-10 w-full max-w-md sm:max-w-lg h-[100dvh] flex flex-col bg-transparent overflow-hidden sm:border-x sm:border-white/10"
      >
        {/* TOP STATUS BAR */}
        <header className="relative z-20 px-3.5 pt-3 pb-2 border-b border-white/10 flex items-center justify-between flex-shrink-0 bg-slate-950/65 backdrop-blur-md">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                if (levelIdx > 0) setLevelIdx((l) => l - 1);
              }}
              disabled={levelIdx === 0}
              className="p-1 rounded-lg hover:bg-white/10 text-white/60 hover:text-white disabled:opacity-30 disabled:pointer-events-none"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <div className="flex flex-col">
              <span className="text-xs font-black tracking-wider text-amber-400 uppercase">
                {t.level} {levelIdx + 1}
              </span>
              <span className="text-[10px] text-white/70 font-medium truncate max-w-[120px]">
                {lang === 'en'
                  ? currentLevelConfig.titleEn || currentLevelConfig.title
                  : currentLevelConfig.title}
              </span>
            </div>

            <button
              onClick={() => {
                if (levelIdx < maxUnlockedLevel) setLevelIdx((l) => l + 1);
              }}
              disabled={levelIdx >= maxUnlockedLevel}
              className="p-1 rounded-lg hover:bg-white/10 text-white/60 hover:text-white disabled:opacity-25 disabled:pointer-events-none transition cursor-pointer"
              title="Next Level"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Moves Count */}
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/10 border border-white/15">
            <span className="text-[9px] text-white/60 uppercase font-bold">{t.moves}</span>
            <span className="text-xs font-black text-white font-mono">{moves}</span>
          </div>

          {/* Audio & Tool Controls */}
          <div className="flex items-center gap-1">
            {/* Ocean Pearl Treasury (🦪 바다 진주) */}
            <button
              onClick={() => setShowVault(true)}
              className="relative p-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/50 text-cyan-300 transition-transform active:scale-95 flex items-center gap-0.5"
              title={t.pearls}
            >
              <span className="text-xs">🦪</span>
              <span className="text-[9px] font-black text-cyan-200 font-mono">
                {totalPearls}
              </span>
            </button>

            {/* Ocean Waves & Bubbles BGM Toggle */}
            <button
              onClick={toggleBgm}
              className={`p-1.5 rounded-xl border transition-all ${
                isBgmOn
                  ? 'bg-emerald-500/20 border-emerald-400/50 text-emerald-300 shadow-[0_0_10px_rgba(16,185,129,0.3)]'
                  : 'bg-white/10 border-white/15 text-slate-500'
              }`}
              title={isBgmOn ? 'BGM Mute' : 'BGM Play'}
            >
              <Music className="w-4 h-4" />
            </button>

            {/* SFX Toggle */}
            <button
              onClick={toggleSfx}
              className={`p-1.5 rounded-xl border transition-all ${
                isSfxOn
                  ? 'bg-cyan-500/20 border-cyan-400/50 text-cyan-300'
                  : 'bg-white/10 border-white/15 text-slate-500'
              }`}
              title={isSfxOn ? 'SFX Mute' : 'SFX Play'}
            >
              {isSfxOn ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Language Switcher (🌐 KO / EN) */}
            <button
              onClick={() => setLang((l) => (l === 'ko' ? 'en' : 'ko'))}
              className="px-2 py-1 rounded-xl bg-white/10 hover:bg-white/20 border border-white/15 text-white/90 text-[10px] font-black tracking-wider transition-all flex items-center gap-1 active:scale-95"
              title="Switch Language"
            >
              <Globe className="w-3.5 h-3.5 text-cyan-400" />
              <span>{lang.toUpperCase()}</span>
            </button>
          </div>
        </header>

        {/* SUB-HEADER BANNER */}
        <div className="px-3.5 py-1.5 bg-gradient-to-r from-cyan-500/15 via-blue-500/15 to-amber-500/15 border-b border-white/10 flex items-center justify-between text-xs flex-shrink-0 backdrop-blur-sm">
          <div className="flex items-center gap-1.5 text-cyan-200 font-semibold text-[10px]">
            <Waves className="w-3.5 h-3.5 text-cyan-300 animate-pulse" />
            <span>{t.oceanRelax}</span>
          </div>

          <button
            onClick={() => setShowHelpGuide((v) => !v)}
            className="flex items-center gap-1 text-[10px] text-white/70 hover:text-white"
          >
            <Info className="w-3 h-3" />
            <span>{t.guide}</span>
          </button>
        </div>

        {/* ACTIVE HINT BANNER */}
        {hintMessage && (
          <div className="mx-3 my-1.5 px-3 py-2 rounded-2xl bg-amber-500/20 border border-amber-400 text-amber-200 text-xs flex items-center gap-2 shadow-lg animate-bounce">
            <Lightbulb className="w-4 h-4 text-amber-300 flex-shrink-0" />
            <span className="font-semibold text-[11px]">{hintMessage}</span>
          </div>
        )}

        {/* HELP GUIDE ACCORDION */}
        {showHelpGuide && (
          <div className="p-3 bg-slate-950/90 border-b border-white/10 text-xs space-y-1.5 flex-shrink-0 animate-[fadeIn_0.2s_ease-out] backdrop-blur-md">
            <p className="font-bold text-amber-300">{t.guideTitle}</p>
            <p className="text-white/85">1. {t.guideStep1}</p>
            <p className="text-white/85">2. {t.guideStep2}</p>
            <p className="text-white/85">3. {t.guideStep3}</p>
            <p className="text-cyan-300">{t.guideTip}</p>
          </div>
        )}

        {/* MAIN GAME FIELD */}
        <main
          onClick={() => {
            if (selectedTubeIdx !== null) {
              setSelectedTubeIdx(null);
              sound.playBallDrop(0, theme === 'aqua');
            }
          }}
          className="flex-1 flex flex-col items-center justify-center py-1 sm:py-2 px-1 relative overflow-visible bg-transparent min-h-0 cursor-default"
        >
          {!isMultiRow ? (
            <div className="w-full flex items-center justify-center gap-x-2 sm:gap-x-3.5 my-auto">
              {tubes.map((tube, idx) => {
                const isSelected = selectedTubeIdx === idx;
                const isHintSrc = activeHint?.fromTubeIdx === idx;
                const isHintTgt = activeHint?.toTubeIdx === idx;

                return (
                  <TestTube
                    key={tube.id}
                    tube={tube}
                    index={idx}
                    isSelected={isSelected}
                    theme={theme}
                    tubeCapacity={currentLevelConfig.tubeCapacity}
                    canReceive={checkCanReceive(idx)}
                    isShaking={shakingTubeIdx === idx}
                    isMultiRow={false}
                    onClick={() => handleTubeClick(idx)}
                    isHintSource={isHintSrc}
                    isHintTarget={isHintTgt}
                  />
                );
              })}
            </div>
          ) : (
            <div className="w-full flex flex-col items-center justify-center gap-y-3 sm:gap-y-4 my-auto">
              {/* Row 1 */}
              <div className="flex items-center justify-center gap-x-1.5 sm:gap-x-2.5">
                {row1Tubes.map((tube, rIdx) => {
                  const actualIdx = rIdx;
                  const isSelected = selectedTubeIdx === actualIdx;
                  const isHintSrc = activeHint?.fromTubeIdx === actualIdx;
                  const isHintTgt = activeHint?.toTubeIdx === actualIdx;

                  return (
                    <TestTube
                      key={tube.id}
                      tube={tube}
                      index={actualIdx}
                      isSelected={isSelected}
                      theme={theme}
                      tubeCapacity={currentLevelConfig.tubeCapacity}
                      canReceive={checkCanReceive(actualIdx)}
                      isShaking={shakingTubeIdx === actualIdx}
                      isMultiRow={true}
                      onClick={() => handleTubeClick(actualIdx)}
                      isHintSource={isHintSrc}
                      isHintTarget={isHintTgt}
                    />
                  );
                })}
              </div>

              {/* Row 2 */}
              <div className="flex items-center justify-center gap-x-1.5 sm:gap-x-2.5">
                {row2Tubes.map((tube, rIdx) => {
                  const actualIdx = row1Tubes.length + rIdx;
                  const isSelected = selectedTubeIdx === actualIdx;
                  const isHintSrc = activeHint?.fromTubeIdx === actualIdx;
                  const isHintTgt = activeHint?.toTubeIdx === actualIdx;

                  return (
                    <TestTube
                      key={tube.id}
                      tube={tube}
                      index={actualIdx}
                      isSelected={isSelected}
                      theme={theme}
                      tubeCapacity={currentLevelConfig.tubeCapacity}
                      canReceive={checkCanReceive(actualIdx)}
                      isShaking={shakingTubeIdx === actualIdx}
                      isMultiRow={true}
                      onClick={() => handleTubeClick(actualIdx)}
                      isHintSource={isHintSrc}
                      isHintTarget={isHintTgt}
                    />
                  );
                })}
              </div>
            </div>
          )}
        </main>

        {/* BOTTOM ACTION BAR */}
        <footer className="relative z-20 px-3.5 py-2.5 border-t border-white/10 bg-slate-950/70 backdrop-blur-md flex-shrink-0">
          <div className="grid grid-cols-4 gap-2">
            <button
              onClick={handleUndo}
              disabled={history.length === 0}
              className="flex flex-col items-center justify-center py-2 px-1 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/15 text-white disabled:opacity-30 disabled:pointer-events-none transition-transform active:scale-95"
            >
              <div className="relative">
                <Undo2 className="w-4 h-4 text-cyan-400" />
                {history.length > 0 && (
                  <span className="absolute -top-1.5 -right-2 text-[8px] font-black text-cyan-300">
                    {history.length}
                  </span>
                )}
              </div>
              <span className="text-[10px] font-semibold text-slate-300 mt-1">
                {t.undo}
              </span>
            </button>

            <button
              onClick={handleRestart}
              className="flex flex-col items-center justify-center py-2 px-1 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/15 text-white transition-transform active:scale-95"
            >
              <RotateCcw className="w-4 h-4 text-amber-400" />
              <span className="text-[10px] font-semibold text-slate-300 mt-1">
                {t.restart}
              </span>
            </button>

            <button
              onClick={handleAddExtraTube}
              disabled={extraTubesCount >= 2}
              className="flex flex-col items-center justify-center py-2 px-1 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/15 text-white disabled:opacity-30 disabled:pointer-events-none transition-transform active:scale-95"
            >
              <div className="relative">
                <PlusCircle className="w-4 h-4 text-emerald-400" />
                <span className="absolute -top-1.5 -right-2 text-[8px] font-bold text-emerald-300">
                  {2 - extraTubesCount}
                </span>
              </div>
              <span className="text-[10px] font-semibold text-slate-300 mt-1">
                {t.addTube}
              </span>
            </button>

            {/* Smart Hint Button */}
            <button
              onClick={handleRequestHint}
              className="flex flex-col items-center justify-center py-2 px-1 rounded-2xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/50 text-amber-300 transition-transform active:scale-95"
            >
              <div className="relative">
                <Lightbulb className="w-4 h-4 text-amber-400" />
                <span className="absolute -top-1.5 -right-2 text-[8px] font-black text-amber-300">
                  {remainingHints}
                </span>
              </div>
              <span className="text-[10px] font-bold text-amber-300 mt-1">
                {t.hint}
              </span>
            </button>
          </div>
        </footer>

        {/* MODALS */}
        <JewelVaultModal
          isOpen={showVault}
          onClose={() => setShowVault(false)}
          gems={craftedGems}
          lang={lang}
        />

        <VictoryModal
          isOpen={showVictory}
          levelNumber={levelIdx + 1}
          moves={moves}
          theme={theme}
          lang={lang}
          newGemsEarned={newGemsEarned}
          earnedPearls={earnedPearls}
          onNextLevel={() => {
            setShowVictory(false);
            setLevelIdx((l) => l + 1); // Infinite progression!
          }}
          onRestartLevel={() => {
            setShowVictory(false);
            initLevel(levelIdx);
          }}
          onOpenVault={() => {
            setShowVictory(false);
            setShowVault(true);
          }}
        />
      </div>
    </div>
  );
}
