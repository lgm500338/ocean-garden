// Ocean Waves & Bubbly Water Drops Audio Engine
// 1. Natural Ocean Surf (파도 소리): Procedural rhythmic wave swell & retreat
// 2. Gentle Water Bubbles & Droplets (물방울 소리): Natural resonant drop chirps
// 3. Interactive SFX (Water lift, splash drop, cork pop, fireworks)
// 4. Independent BGM & SFX controls

class SoundEngine {
  private ctx: AudioContext | null = null;
  private sfxGain: GainNode | null = null;
  private bgmGain: GainNode | null = null;
  private masterGain: GainNode | null = null;

  private isBgmPlaying: boolean = false;
  private isBgmMuted: boolean = false;
  private isSfxMuted: boolean = false;

  // Wave & Bubble timers
  private waveGainNode: GainNode | null = null;
  private waveFilterNode: BiquadFilterNode | null = null;
  private noiseSource: AudioBufferSourceNode | null = null;
  private waveIntervalId: number | null = null;
  private bubbleIntervalId: number | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      const unlock = () => {
        this.unlockAudio();
        window.removeEventListener('pointerdown', unlock);
        window.removeEventListener('keydown', unlock);
        window.removeEventListener('touchstart', unlock);
      };
      window.addEventListener('pointerdown', unlock, { passive: true });
      window.addEventListener('keydown', unlock, { passive: true });
      window.addEventListener('touchstart', unlock, { passive: true });

      // 앱이 백그라운드로 가면(홈 버튼, 화면 꺼짐, 다른 앱 전환) 모든 소리를 멈추고
      // 다시 돌아오면 이어서 재생
      document.addEventListener('visibilitychange', () => {
        if (!this.ctx) return;
        if (document.hidden) {
          if (this.ctx.state === 'running') this.ctx.suspend().catch(() => {});
        } else if (this.ctx.state === 'suspended') {
          this.ctx.resume().catch(() => {});
        }
      });
      window.addEventListener('pagehide', () => {
        if (this.ctx && this.ctx.state === 'running') this.ctx.suspend().catch(() => {});
      });
    }
  }

  public unlockAudio() {
    try {
      if (!this.ctx && typeof window !== 'undefined') {
        const AudioCtx =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext })
            .webkitAudioContext;
        if (AudioCtx) {
          this.ctx = new AudioCtx();

          this.masterGain = this.ctx.createGain();
          this.masterGain.gain.setValueAtTime(0.8, this.ctx.currentTime);
          this.masterGain.connect(this.ctx.destination);

          this.sfxGain = this.ctx.createGain();
          this.sfxGain.gain.setValueAtTime(
            this.isSfxMuted ? 0 : 0.7,
            this.ctx.currentTime
          );
          this.sfxGain.connect(this.masterGain);

          this.bgmGain = this.ctx.createGain();
          this.bgmGain.gain.setValueAtTime(
            this.isBgmMuted ? 0 : 0.55,
            this.ctx.currentTime
          );
          this.bgmGain.connect(this.masterGain);
        }
      }
      if (this.ctx && this.ctx.state === 'suspended') {
        this.ctx
          .resume()
          .then(() => {
            if (!this.isBgmPlaying && !this.isBgmMuted) {
              this.startOceanBGM();
            }
          })
          .catch(() => {});
      } else if (this.ctx && !this.isBgmPlaying && !this.isBgmMuted) {
        this.startOceanBGM();
      }
    } catch {
      // Safe fallback
    }
  }

  // -------------------------------------------------------------
  // OCEAN WAVES & WATER DROPS BGM (자연의 파도 소리 + 맑은 물방울 ASMR)
  // -------------------------------------------------------------
  public startOceanBGM() {
    if (this.isBgmPlaying || !this.ctx || !this.bgmGain) return;
    this.isBgmPlaying = true;

    // 1. Generate Organic Pink/Brown Noise Buffer for Ocean Surf (5 seconds loop)
    const bufferSize = this.ctx.sampleRate * 5;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);

    let lastOut = 0.0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      // Brown noise integration for warm, deep ocean surf roar
      lastOut = (lastOut + 0.025 * white) / 1.02;
      output[i] = lastOut * 3.5;
    }

    this.noiseSource = this.ctx.createBufferSource();
    this.noiseSource.buffer = noiseBuffer;
    this.noiseSource.loop = true;

    // Ocean Filter: softens high frequencies into soothing rushing seafoam
    this.waveFilterNode = this.ctx.createBiquadFilter();
    this.waveFilterNode.type = 'lowpass';
    this.waveFilterNode.frequency.setValueAtTime(260, this.ctx.currentTime);
    this.waveFilterNode.Q.setValueAtTime(1.5, this.ctx.currentTime);

    this.waveGainNode = this.ctx.createGain();
    this.waveGainNode.gain.setValueAtTime(0.08, this.ctx.currentTime);

    this.noiseSource.connect(this.waveFilterNode);
    this.waveFilterNode.connect(this.waveGainNode);
    this.waveGainNode.connect(this.bgmGain);

    this.noiseSource.start();

    // Natural Wave Swell Cycle (7.5-second breathing wave: 쏴아아아... 쉬이이익...)
    let wavePhase = 0;
    this.waveIntervalId = window.setInterval(() => {
      if (!this.ctx || !this.waveGainNode || !this.waveFilterNode || !this.isBgmPlaying) return;
      wavePhase += 0.05;

      const now = this.ctx.currentTime;
      // Gentle sine wave modulation
      const swell = (Math.sin(wavePhase) + 1) / 2; // 0 to 1
      const targetGain = 0.04 + swell * 0.16; // 0.04 (calm) to 0.20 (crest)
      const targetFreq = 180 + swell * 320; // 180Hz (deep wash) to 500Hz (splash)

      this.waveGainNode.gain.linearRampToValueAtTime(targetGain, now + 0.1);
      this.waveFilterNode.frequency.linearRampToValueAtTime(targetFreq, now + 0.1);
    }, 100);

    // 2. Playful Water Droplets & Bubbles (뽀글... 퐁... 퐁당!)
    const playNaturalWaterDrop = () => {
      if (!this.ctx || !this.bgmGain || !this.isBgmPlaying) return;

      const now = this.ctx.currentTime;
      const baseFreq = 420 + Math.random() * 480; // 420Hz - 900Hz water pitch

      const osc = this.ctx.createOscillator();
      const dropGain = this.ctx.createGain();

      osc.type = 'sine';
      // Upward frequency sweep mimics natural water droplet surface tension pop
      osc.frequency.setValueAtTime(baseFreq, now);
      osc.frequency.exponentialRampToValueAtTime(baseFreq * 2.2, now + 0.07);

      dropGain.gain.setValueAtTime(0.001, now);
      dropGain.gain.linearRampToValueAtTime(0.18, now + 0.008);
      dropGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.28);

      osc.connect(dropGain);
      dropGain.connect(this.bgmGain);

      osc.start(now);
      osc.stop(now + 0.3);

      // Occasional companion bubble echo (뽀글)
      if (Math.random() < 0.5) {
        const bubbleTime = now + 0.08 + Math.random() * 0.06;
        const bOsc = this.ctx.createOscillator();
        const bGain = this.ctx.createGain();

        bOsc.type = 'sine';
        bOsc.frequency.setValueAtTime(baseFreq * 1.5, bubbleTime);
        bOsc.frequency.exponentialRampToValueAtTime(baseFreq * 2.8, bubbleTime + 0.05);

        bGain.gain.setValueAtTime(0.001, bubbleTime);
        bGain.gain.linearRampToValueAtTime(0.12, bubbleTime + 0.006);
        bGain.gain.exponentialRampToValueAtTime(0.0001, bubbleTime + 0.18);

        bOsc.connect(bGain);
        bGain.connect(this.bgmGain);

        bOsc.start(bubbleTime);
        bOsc.stop(bubbleTime + 0.2);
      }
    };

    // Trigger water droplets every 1.2 to 2.4 seconds
    const scheduleNextDrop = () => {
      if (!this.isBgmPlaying) return;
      playNaturalWaterDrop();
      const nextDelay = 1200 + Math.random() * 1400;
      this.bubbleIntervalId = window.setTimeout(scheduleNextDrop, nextDelay);
    };

    scheduleNextDrop();
  }

  public stopOceanBGM() {
    this.isBgmPlaying = false;
    if (this.waveIntervalId) {
      clearInterval(this.waveIntervalId);
      this.waveIntervalId = null;
    }
    if (this.bubbleIntervalId) {
      clearTimeout(this.bubbleIntervalId);
      this.bubbleIntervalId = null;
    }
    if (this.noiseSource) {
      try {
        this.noiseSource.stop();
        this.noiseSource.disconnect();
      } catch {
        // safe
      }
      this.noiseSource = null;
    }
  }

  public setBgmMuted(muted: boolean) {
    this.isBgmMuted = muted;
    if (this.bgmGain && this.ctx) {
      this.bgmGain.gain.setValueAtTime(muted ? 0 : 0.55, this.ctx.currentTime);
    }
    if (muted) {
      this.stopOceanBGM();
    } else {
      this.startOceanBGM();
    }
  }

  public getBgmMuted(): boolean {
    return this.isBgmMuted;
  }

  public setSfxMuted(muted: boolean) {
    this.isSfxMuted = muted;
    if (this.sfxGain && this.ctx) {
      this.sfxGain.gain.setValueAtTime(muted ? 0 : 0.7, this.ctx.currentTime);
    }
  }

  public getSfxMuted(): boolean {
    return this.isSfxMuted;
  }

  public haptic(pattern: number | number[] = 15) {
    if (typeof window !== 'undefined' && 'navigator' in window && navigator.vibrate) {
      try {
        navigator.vibrate(pattern);
      } catch {
        // Safe fallback
      }
    }
  }

  // SFX: 1. 구슬 들어올릴 때 (물방울 퐁!)
  public playBallLift(isAquaTheme: boolean = true) {
    if (this.isSfxMuted) return;
    this.unlockAudio();
    if (!this.ctx || !this.sfxGain) return;

    this.haptic(12);
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(340, now);
    osc.frequency.exponentialRampToValueAtTime(1150, now + 0.08);

    gain.gain.setValueAtTime(0.38, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.12);
  }

  // SFX: 2. 구슬 착지할 때 (퐁당! 뽀글뽀글~)
  public playBallDrop(index: number = 0, isAquaTheme: boolean = true) {
    if (this.isSfxMuted) return;
    this.unlockAudio();
    if (!this.ctx || !this.sfxGain) return;

    this.haptic(20);
    const now = this.ctx.currentTime;

    const scale = [440, 523, 587, 659, 784, 880, 987, 1046];
    const baseFreq = scale[index % scale.length];

    // Splash transient
    const osc1 = this.ctx.createOscillator();
    const gain1 = this.ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(baseFreq * 1.6, now);
    osc1.frequency.exponentialRampToValueAtTime(baseFreq, now + 0.05);
    osc1.frequency.exponentialRampToValueAtTime(baseFreq * 0.7, now + 0.25);

    gain1.gain.setValueAtTime(0.48, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc1.connect(gain1);
    gain1.connect(this.sfxGain);
    osc1.start(now);
    osc1.stop(now + 0.35);

    // Bubble trickle (뽀글)
    const osc2 = this.ctx.createOscillator();
    const gain2 = this.ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(baseFreq * 1.3, now + 0.07);
    osc2.frequency.exponentialRampToValueAtTime(baseFreq * 2.4, now + 0.18);

    gain2.gain.setValueAtTime(0.24, now + 0.07);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.24);

    osc2.connect(gain2);
    gain2.connect(this.sfxGain);
    osc2.start(now + 0.07);
    osc2.stop(now + 0.24);
  }

  // SFX: 3. 힌트 알림음
  public playHintChime() {
    if (this.isSfxMuted) return;
    this.unlockAudio();
    if (!this.ctx || !this.sfxGain) return;

    this.haptic([15, 20]);
    const now = this.ctx.currentTime;
    const notes = [523.25, 659.25, 783.99];

    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const t = now + idx * 0.08;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t);

      gain.gain.setValueAtTime(0.25, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(t);
      osc.stop(t + 0.35);
    });
  }

  // SFX: 4. 코르크 마개 퐁!
  public playCorkPop() {
    if (this.isSfxMuted) return;
    this.unlockAudio();
    if (!this.ctx || !this.sfxGain) return;

    this.haptic([20, 30, 20]);
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(150, now);
    osc.frequency.exponentialRampToValueAtTime(900, now + 0.035);
    osc.frequency.exponentialRampToValueAtTime(110, now + 0.14);

    gain.gain.setValueAtTime(0.48, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);

    osc.connect(gain);
    gain.connect(this.sfxGain);

    osc.start(now);
    osc.stop(now + 0.16);
  }

  // SFX: 5. 폭죽 발사 및 폭발
  public playFireworksExplosion() {
    if (this.isSfxMuted) return;
    this.unlockAudio();
    if (!this.ctx || !this.sfxGain) return;

    this.haptic([25, 40, 50, 70]);
    const now = this.ctx.currentTime;

    const whistle = this.ctx.createOscillator();
    const whistleGain = this.ctx.createGain();
    whistle.type = 'sine';
    whistle.frequency.setValueAtTime(400, now);
    whistle.frequency.exponentialRampToValueAtTime(1400, now + 0.25);
    whistleGain.gain.setValueAtTime(0.2, now);
    whistleGain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);
    whistle.connect(whistleGain);
    whistleGain.connect(this.sfxGain);
    whistle.start(now);
    whistle.stop(now + 0.25);

    const boomTime = now + 0.25;
    const boomOsc = this.ctx.createOscillator();
    const boomGain = this.ctx.createGain();
    boomOsc.type = 'triangle';
    boomOsc.frequency.setValueAtTime(180, boomTime);
    boomOsc.frequency.exponentialRampToValueAtTime(45, boomTime + 0.35);
    boomGain.gain.setValueAtTime(0.55, boomTime);
    boomGain.gain.exponentialRampToValueAtTime(0.001, boomTime + 0.4);
    boomOsc.connect(boomGain);
    boomGain.connect(this.sfxGain);
    boomOsc.start(boomTime);
    boomOsc.stop(boomTime + 0.4);

    const sparkles = [1046.5, 1318.5, 1567.98, 2093.0, 2637.0];
    sparkles.forEach((freq, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const spTime = boomTime + 0.08 + idx * 0.05;
      const spOsc = this.ctx.createOscillator();
      const spGain = this.ctx.createGain();
      spOsc.type = 'sine';
      spOsc.frequency.setValueAtTime(freq, spTime);
      spGain.gain.setValueAtTime(0.2, spTime);
      spGain.gain.exponentialRampToValueAtTime(0.001, spTime + 0.45);
      spOsc.connect(spGain);
      spGain.connect(this.sfxGain);
      spOsc.start(spTime);
      spOsc.stop(spTime + 0.45);
    });
  }

  // SFX: 6. 보석 융합
  public playGemFusion() {
    if (this.isSfxMuted) return;
    this.unlockAudio();
    if (!this.ctx || !this.sfxGain) return;

    this.haptic([15, 25, 35, 45]);
    const now = this.ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5, 1318.5];

    notes.forEach((freq, i) => {
      if (!this.ctx || !this.sfxGain) return;
      const noteTime = now + i * 0.06;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, noteTime);

      gain.gain.setValueAtTime(0.3, noteTime);
      gain.gain.exponentialRampToValueAtTime(0.001, noteTime + 0.4);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(noteTime);
      osc.stop(noteTime + 0.4);
    });
  }

  // SFX: 7. 스테이지 클리어
  public playStageClear() {
    if (this.isSfxMuted) return;
    this.unlockAudio();
    if (!this.ctx || !this.sfxGain) return;

    this.haptic([30, 50, 60, 90]);
    const now = this.ctx.currentTime;
    const chords = [
      [523.25, 659.25, 783.99],
      [587.33, 739.99, 880.0],
      [659.25, 830.61, 987.77, 1318.51],
    ];

    chords.forEach((chord, step) => {
      const stepTime = now + step * 0.16;
      chord.forEach((freq) => {
        if (!this.ctx || !this.sfxGain) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, stepTime);

        gain.gain.setValueAtTime(0.3, stepTime);
        gain.gain.exponentialRampToValueAtTime(
          0.001,
          stepTime + (step === chords.length - 1 ? 1.0 : 0.28)
        );

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(stepTime);
        osc.stop(stepTime + 1.1);
      });
    });
  }
}

export const sound = new SoundEngine();
