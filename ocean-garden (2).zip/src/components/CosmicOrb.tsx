import React from 'react';
import { BallColor, ThemeType } from '../types';

interface CosmicOrbProps {
  color: BallColor;
  theme: ThemeType;
  isFloating?: boolean;
  isFusing?: boolean;
  isSwimming?: boolean;
  swimDelay?: number;
  size?: number; // px
  isHintSource?: boolean;
  isHintTarget?: boolean;
}

export const CosmicOrb: React.FC<CosmicOrbProps> = ({
  color,
  theme,
  isFloating = false,
  isFusing = false,
  isSwimming = false,
  swimDelay = 0,
  size = 32,
  isHintSource = false,
  isHintTarget = false,
}) => {
  const uniqueId = `orb-${color}-${Math.floor(Math.random() * 100000)}`;

  // =========================================================================
  // AQUA THEME: FULL-BODY ROUND 3D SEA CREATURE ORBS (구슬 전체를 덮는 바다생물)
  // No billiard ball white circles! The entire 3D sphere is the creature itself!
  // =========================================================================
  if (theme === 'aqua') {
    return (
      <div
        className={`relative rounded-full select-none transition-all duration-200 flex items-center justify-center ${
          isSwimming ? 'animate-fish-swim' : ''
        } ${
          isFloating ? '-translate-y-4 scale-110 drop-shadow-[0_0_18px_rgba(56,189,248,0.9)]' : 'hover:scale-105'
        } ${isFusing ? 'scale-0 opacity-0 transition-all duration-300' : ''} ${
          isHintSource ? 'animate-bounce drop-shadow-[0_0_22px_#22c55e]' : ''
        } ${isHintTarget ? 'drop-shadow-[0_0_22px_#38bdf8]' : ''}`}
        style={{
          width: `${size}px`,
          height: `${size}px`,
          filter: 'drop-shadow(0 4px 8px rgba(0,0,0,0.5))',
          animationDelay: `${swimDelay}s`,
        }}
      >
        <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible">
          <defs>
            {/* 3D Sphere Shading Mask */}
            <radialGradient id={`sphere-light-${uniqueId}`} cx="32%" cy="28%" r="72%">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0.85" />
              <stop offset="25%" stopColor="#ffffff" stopOpacity="0.2" />
              <stop offset="70%" stopColor="#000000" stopOpacity="0.1" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0.65" />
            </radialGradient>

            {/* Pufferfish (복어 - Amber) */}
            <radialGradient id={`puffer-base-${uniqueId}`} cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="45%" stopColor="#f59e0b" />
              <stop offset="85%" stopColor="#b45309" />
              <stop offset="100%" stopColor="#451a03" />
            </radialGradient>

            {/* Clownfish (니모 - Ruby) */}
            <radialGradient id={`nemo-base-${uniqueId}`} cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#ffedd5" />
              <stop offset="35%" stopColor="#f97316" />
              <stop offset="80%" stopColor="#ea580c" />
              <stop offset="100%" stopColor="#7c2d12" />
            </radialGradient>

            {/* Turtle (거북이 - Emerald) */}
            <radialGradient id={`turtle-base-${uniqueId}`} cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#a7f3d0" />
              <stop offset="35%" stopColor="#10b981" />
              <stop offset="80%" stopColor="#047857" />
              <stop offset="100%" stopColor="#022c22" />
            </radialGradient>

            {/* Dolphin (돌고래 - Sapphire) */}
            <radialGradient id={`dolphin-base-${uniqueId}`} cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#bae6fd" />
              <stop offset="35%" stopColor="#0284c7" />
              <stop offset="80%" stopColor="#1d4ed8" />
              <stop offset="100%" stopColor="#0f172a" />
            </radialGradient>

            {/* Jellyfish (해파리 - Violet) */}
            <radialGradient id={`jelly-base-${uniqueId}`} cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#f5d0fe" />
              <stop offset="35%" stopColor="#c084fc" />
              <stop offset="80%" stopColor="#7e22ce" />
              <stop offset="100%" stopColor="#3b0764" />
            </radialGradient>

            {/* Shark (아기상어 - Cyan) */}
            <radialGradient id={`shark-base-${uniqueId}`} cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#cffafe" />
              <stop offset="35%" stopColor="#06b6d4" />
              <stop offset="80%" stopColor="#0369a1" />
              <stop offset="100%" stopColor="#082f49" />
            </radialGradient>

            {/* Golden Whale (황금고래 - Gold) */}
            <radialGradient id={`gold-base-${uniqueId}`} cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="40%" stopColor="#eab308" />
              <stop offset="80%" stopColor="#a16207" />
              <stop offset="100%" stopColor="#422006" />
            </radialGradient>
          </defs>

          {/* ============================================================== */}
          {/* 1. CLOWNFISH BALL (주황/루비 - 니모 구슬: 구슬 전체를 두른 흰 줄무늬와 지느러미) */}
          {/* ============================================================== */}
          {color === 'ruby' && (
            <g>
              {/* Base body */}
              <circle cx="50" cy="50" r="47" fill={`url(#nemo-base-${uniqueId})`} />
              
              {/* Characteristic Curved Clownfish White Bands (구슬을 감싸는 리얼 흰색 줄무늬) */}
              <path
                d="M 32 4 Q 38 50 32 96 L 44 96 Q 52 50 44 4 Z"
                fill="#ffffff"
                stroke="#1e293b"
                strokeWidth="1.5"
                opacity="0.95"
              />
              <path
                d="M 66 8 Q 72 50 66 92 L 75 88 Q 80 50 75 12 Z"
                fill="#ffffff"
                stroke="#1e293b"
                strokeWidth="1.5"
                opacity="0.95"
              />

              {/* Cute Fin on side */}
              <path d="M 46 48 Q 58 40 54 58 Z" fill="#ea580c" stroke="#1e293b" strokeWidth="1" />

              {/* Big Expressive Fish Eye */}
              <circle cx="22" cy="40" r="8" fill="#ffffff" stroke="#1e293b" strokeWidth="1" />
              <circle cx="20" cy="40" r="4.5" fill="#0f172a" />
              <circle cx="18" cy="38" r="2" fill="#ffffff" />
            </g>
          )}

          {/* ============================================================== */}
          {/* 2. PUFFERFISH BALL (앰버/노랑 - 복어 구슬: 구슬 전체에 귀여운 가시와 땡글 눈) */}
          {/* ============================================================== */}
          {color === 'amber' && (
            <g>
              {/* Spines around edge */}
              <path
                d="M 50 2 L 53 6 L 50 8 Z M 75 10 L 80 14 L 75 17 Z M 92 30 L 96 35 L 90 38 Z M 95 65 L 98 70 L 91 72 Z M 75 88 L 78 94 L 72 91 Z M 50 94 L 48 98 L 46 93 Z M 25 88 L 20 93 L 24 86 Z M 6 65 L 2 68 L 7 72 Z M 5 35 L 1 32 L 7 28 Z M 25 10 L 21 6 L 26 14 Z"
                fill="#b45309"
              />

              {/* Puffer Ball body */}
              <circle cx="50" cy="50" r="46" fill={`url(#puffer-base-${uniqueId})`} />

              {/* White belly gradient */}
              <ellipse cx="50" cy="65" rx="34" ry="20" fill="#fef3c7" opacity="0.65" />

              {/* Little body dots/spines pattern */}
              <circle cx="36" cy="48" r="2" fill="#78350f" opacity="0.4" />
              <circle cx="50" cy="38" r="2" fill="#78350f" opacity="0.4" />
              <circle cx="64" cy="48" r="2" fill="#78350f" opacity="0.4" />
              <circle cx="42" cy="62" r="2" fill="#78350f" opacity="0.4" />
              <circle cx="58" cy="62" r="2" fill="#78350f" opacity="0.4" />

              {/* Big Puffer Eyes */}
              <circle cx="34" cy="36" r="7.5" fill="#ffffff" stroke="#78350f" strokeWidth="1" />
              <circle cx="34" cy="36" r="4" fill="#0f172a" />
              <circle cx="32" cy="34" r="1.8" fill="#ffffff" />

              <circle cx="66" cy="36" r="7.5" fill="#ffffff" stroke="#78350f" strokeWidth="1" />
              <circle cx="66" cy="36" r="4" fill="#0f172a" />
              <circle cx="64" cy="34" r="1.8" fill="#ffffff" />

              {/* Pouty Lips */}
              <ellipse cx="50" cy="46" rx="4.5" ry="3" fill="#ea580c" />
            </g>
          )}

          {/* ============================================================== */}
          {/* 3. SEA TURTLE BALL (에메랄드/초록 - 바다거북 등딱지 구슬) */}
          {/* ============================================================== */}
          {color === 'emerald' && (
            <g>
              {/* Base sphere */}
              <circle cx="50" cy="50" r="47" fill={`url(#turtle-base-${uniqueId})`} />

              {/* Hexagonal Turtle Shell Plates (구슬 전체를 덮는 거북 등딱지 비늘) */}
              <polygon
                points="50,28 66,38 66,62 50,72 34,62 34,38"
                fill="#047857"
                stroke="#6ee7b7"
                strokeWidth="2"
              />
              <line x1="50" y1="28" x2="50" y2="4" stroke="#6ee7b7" strokeWidth="2" />
              <line x1="66" y1="38" x2="88" y2="24" stroke="#6ee7b7" strokeWidth="2" />
              <line x1="66" y1="62" x2="88" y2="76" stroke="#6ee7b7" strokeWidth="2" />
              <line x1="50" y1="72" x2="50" y2="96" stroke="#6ee7b7" strokeWidth="2" />
              <line x1="34" y1="62" x2="12" y2="76" stroke="#6ee7b7" strokeWidth="2" />
              <line x1="34" y1="38" x2="12" y2="24" stroke="#6ee7b7" strokeWidth="2" />

              {/* Center Shell Pattern Emblem */}
              <polygon
                points="50,38 58,44 58,56 50,62 42,56 42,44"
                fill="#065f46"
                stroke="#a7f3d0"
                strokeWidth="1.2"
              />

              {/* Turtle Flippers peek */}
              <ellipse cx="14" cy="28" rx="8" ry="4" transform="rotate(-30 14 28)" fill="#059669" />
              <ellipse cx="86" cy="28" rx="8" ry="4" transform="rotate(30 86 28)" fill="#059669" />
            </g>
          )}

          {/* ============================================================== */}
          {/* 4. DOLPHIN BALL (사파이어/파랑 - 심해 돌고래 구슬) */}
          {/* ============================================================== */}
          {color === 'sapphire' && (
            <g>
              {/* Base body */}
              <circle cx="50" cy="50" r="47" fill={`url(#dolphin-base-${uniqueId})`} />

              {/* Oceanic Belly Arc */}
              <path
                d="M 12 56 Q 50 82 88 56 Q 50 96 12 56 Z"
                fill="#f0f9ff"
                opacity="0.85"
              />

              {/* Curved Dorsal Fin Silhouette across the orb */}
              <path
                d="M 50 14 Q 58 4 66 18 Q 56 22 50 14 Z"
                fill="#0369a1"
                stroke="#38bdf8"
                strokeWidth="1"
              />

              {/* Sleek Dolphin Eye & Blowhole */}
              <circle cx="34" cy="38" r="5" fill="#ffffff" />
              <circle cx="35" cy="38" r="3" fill="#0f172a" />
              <circle cx="33" cy="36" r="1.2" fill="#ffffff" />
              <ellipse cx="50" cy="24" rx="3.5" ry="1.2" fill="#0c4a6e" />
            </g>
          )}

          {/* ============================================================== */}
          {/* 5. JELLYFISH BALL (바이올렛/보라 - 심해 발광 해파리 구슬) */}
          {/* ============================================================== */}
          {color === 'violet' && (
            <g>
              {/* Base sphere */}
              <circle cx="50" cy="50" r="47" fill={`url(#jelly-base-${uniqueId})`} />

              {/* Luminous Jellyfish Bell Dome (반투명 해파리 머리 갓) */}
              <path
                d="M 22 45 Q 50 12 78 45 Q 68 52 50 48 Q 32 52 22 45 Z"
                fill="#f3e8ff"
                opacity="0.75"
                filter="drop-shadow(0 0 6px #d8b4fe)"
              />

              {/* Flowing Bioluminescent Tentacles (구슬 전체에 흐르는 촉수) */}
              <path
                d="M 32 48 Q 28 68 34 88 M 44 50 Q 40 72 46 90 M 56 50 Q 60 72 54 90 M 68 48 Q 72 68 66 88"
                fill="none"
                stroke="#fdf4ff"
                strokeWidth="2.2"
                strokeLinecap="round"
                opacity="0.85"
              />

              {/* Glowing Sparkle points inside jellyfish */}
              <circle cx="40" cy="34" r="2.5" fill="#ffffff" />
              <circle cx="60" cy="34" r="2.5" fill="#ffffff" />
              <circle cx="50" cy="26" r="2" fill="#ffffff" />
            </g>
          )}

          {/* ============================================================== */}
          {/* 6. BABY SHARK BALL (시안/하늘 - 아기상어 구슬) */}
          {color === 'cyan' && (
            <g>
              <circle cx="50" cy="50" r="47" fill={`url(#shark-base-${uniqueId})`} />
              
              {/* Shark White Belly */}
              <path d="M 14 50 Q 50 84 86 50 Q 50 94 14 50 Z" fill="#f8fafc" opacity="0.9" />

              {/* Shark Dorsal Fin on top */}
              <path d="M 50 16 L 62 4 L 56 22 Z" fill="#0284c7" stroke="#38bdf8" strokeWidth="1" />

              {/* Gills slits */}
              <path d="M 64 42 Q 62 50 64 58 M 69 44 Q 67 50 69 56 M 74 46 Q 72 50 74 54" stroke="#0369a1" strokeWidth="1.5" fill="none" />

              {/* Shark Eye */}
              <circle cx="32" cy="38" r="5" fill="#ffffff" />
              <circle cx="32" cy="38" r="3" fill="#0f172a" />
              <circle cx="30" cy="36" r="1.2" fill="#ffffff" />
            </g>
          )}

          {/* ============================================================== */}
          {/* 7. GOLDEN WHALE / STARFISH (골드 - 황금 고래 & 진주 구슬) */}
          {color === 'gold' && (
            <g>
              <circle cx="50" cy="50" r="47" fill={`url(#gold-base-${uniqueId})`} />

              {/* Big Golden Starfish Arms embossed over entire ball */}
              <polygon
                points="50,10 61,35 88,38 67,56 73,84 50,68 27,84 33,56 12,38 39,35"
                fill="#fde047"
                stroke="#ca8a04"
                strokeWidth="1.5"
                opacity="0.85"
              />
              <circle cx="50" cy="50" r="8" fill="#ffffff" opacity="0.6" />

              {/* Whale Spout Heart */}
              <path d="M 50 20 Q 54 8 60 14 Q 50 24 50 20 Z" fill="#ffffff" opacity="0.8" />
              <path d="M 50 20 Q 46 8 40 14 Q 50 24 50 20 Z" fill="#ffffff" opacity="0.8" />
            </g>
          )}

          {/* ============================================================== */}
          {/* 3D Glass Sphere Highlight Overlays (구슬 전체 입체 렌즈 광택) */}
          {/* ============================================================== */}
          <circle cx="50" cy="50" r="47" fill={`url(#sphere-light-${uniqueId})`} pointerEvents="none" />

          {/* Glossy Curved Highlight */}
          <ellipse
            cx="40"
            cy="20"
            rx="18"
            ry="7"
            transform="rotate(-28 40 20)"
            fill="#ffffff"
            opacity="0.75"
            pointerEvents="none"
          />

          {/* Bottom Caustic Rim Reflection */}
          <ellipse cx="50" cy="88" rx="20" ry="4" fill="#ffffff" opacity="0.3" pointerEvents="none" />
        </svg>
      </div>
    );
  }

  // =========================================================================
  // OTHER THEMES (Cosmic, Jelly, Alchemy)
  // =========================================================================
  return (
    <div
      className={`relative rounded-full select-none transition-all duration-200 flex items-center justify-center ${
        isFloating ? '-translate-y-4 scale-110 drop-shadow-[0_0_16px_rgba(168,85,247,0.9)]' : 'hover:scale-105'
      } ${isFusing ? 'scale-0 opacity-0 transition-all duration-300' : ''}`}
      style={{
        width: `${size}px`,
        height: `${size}px`,
      }}
    >
      <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible">
        <circle cx="50" cy="50" r="46" fill="#3b0764" />
        <circle cx="50" cy="50" r="45" fill="none" stroke="#d8b4fe" strokeWidth="2" />
        <text x="50" y="58" fontSize="26" textAnchor="middle" fill="#ffffff">
          ✦
        </text>
      </svg>
    </div>
  );
};
