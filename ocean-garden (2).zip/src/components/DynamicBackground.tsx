import React, { useEffect, useRef, useState } from 'react';
import { ThemeType } from '../types';

interface DynamicBackgroundProps {
  theme: ThemeType;
  levelNumber?: number;
}

// 실제 바다 사진 (Pexels 라이선스: 상업적 이용 가능, 출처 표기 불필요)
// src/assets/backgrounds 폴더의 ocean1.jpg, ocean2.jpg ... 를 자동으로 모두 불러옴
// 사진을 늘리려면 ocean11.jpg 처럼 번호를 이어서 파일만 넣으면 됨 (코드 수정 불필요)
const photoModules = import.meta.glob('../assets/backgrounds/ocean*.jpg', {
  eager: true,
  import: 'default',
}) as Record<string, string>;

export const OCEAN_PHOTOS = Object.keys(photoModules)
  .sort((a, b) => parseInt(a.match(/ocean(\d+)/)![1]) - parseInt(b.match(/ocean(\d+)/)![1]))
  .map((k) => photoModules[k]);

const photoForLevel = (level: number) =>
  OCEAN_PHOTOS[(Math.max(1, level) - 1) % OCEAN_PHOTOS.length];

// ------------------------------------------------------------------
// 물속 효과 셰이더: 사진 전체가 물을 통해 보이듯 아주 살짝 일렁이고,
// 수면에서 들어오는 빛 무늬(코스틱)와 빛줄기가 천천히 움직인다.
// ------------------------------------------------------------------
const VERT = `
attribute vec2 aPos;
varying vec2 vUv;
void main() {
  vUv = aPos * 0.5 + 0.5;
  gl_Position = vec4(aPos, 0.0, 1.0);
}`;

const FRAG = `
precision mediump float;
varying vec2 vUv;
uniform sampler2D uTex0;
uniform sampler2D uTex1;
uniform vec2 uRes;
uniform vec2 uSize0;
uniform vec2 uSize1;
uniform float uMix;
uniform float uTime;

vec2 coverUv(vec2 uv, vec2 imgSize) {
  float sr = uRes.x / uRes.y;
  float ir = imgSize.x / imgSize.y;
  vec2 scale = sr > ir ? vec2(1.0, ir / sr) : vec2(sr / ir, 1.0);
  return (uv - 0.5) * scale + 0.5;
}

void main() {
  vec2 uv = vUv;
  float t = uTime;

  // 아주 느린 숨쉬기 줌 (사진이 정지해 보이지 않도록)
  float zoom = 1.06 + 0.02 * sin(t * 0.12);
  uv = (uv - 0.5) / zoom + 0.5 + vec2(sin(t * 0.07), cos(t * 0.05)) * 0.006;

  // 물결 일렁임: 물고기와 산호가 물속에서 흔들리는 느낌
  vec2 d;
  d.x = sin(uv.y * 16.0 + t * 1.1) * 0.0022 + sin(uv.y * 38.0 - t * 1.6 + uv.x * 5.0) * 0.0010;
  d.y = cos(uv.x * 14.0 + t * 0.9) * 0.0018 + sin(uv.x * 33.0 + t * 1.3) * 0.0008;
  uv += d;

  vec3 c0 = texture2D(uTex0, coverUv(uv, uSize0)).rgb;
  vec3 c1 = texture2D(uTex1, coverUv(uv, uSize1)).rgb;
  vec3 col = mix(c0, c1, uMix);

  // 수면에서 내려오는 빛 무늬 (위쪽일수록 강함)
  vec2 p = vUv * vec2(uRes.x / uRes.y, 1.0) * 7.0;
  float c = sin(p.x + sin(p.y * 1.3 + t * 0.6)) * sin(p.y * 1.1 + sin(p.x * 0.9 - t * 0.5));
  c = pow(max(c, 0.0), 3.0);
  float topFade = smoothstep(0.25, 1.0, vUv.y);
  col += vec3(0.75, 0.95, 1.0) * c * 0.13 * topFade;

  // 흔들리는 빛줄기
  float r = sin((vUv.x + vUv.y * 0.35) * 20.0 + sin(t * 0.35) * 1.8) * 0.5 + 0.5;
  r = pow(r, 10.0) * smoothstep(0.2, 1.0, vUv.y);
  col += vec3(0.8, 0.95, 1.0) * r * 0.10;

  // 게임 화면이 잘 보이도록 살짝 어둡게 + 가장자리 비네팅
  float vig = smoothstep(1.05, 0.35, distance(vUv, vec2(0.5, 0.5)));
  col *= 0.82 * mix(0.72, 1.0, vig);

  gl_FragColor = vec4(col, 1.0);
}`;

function compile(gl: WebGLRenderingContext, type: number, src: string) {
  const s = gl.createShader(type)!;
  gl.shaderSource(s, src);
  gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) || 'shader');
  return s;
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

export const DynamicBackground: React.FC<DynamicBackgroundProps> = ({ levelNumber = 1 }) => {
  const glCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const bubbleCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [webglFailed, setWebglFailed] = useState(false);
  const photo = photoForLevel(levelNumber);

  // WebGL 엔진 상태 (레벨 바뀔 때 사진만 교체)
  const engineRef = useRef<{
    setPhoto: (src: string) => void;
  } | null>(null);

  // ---------------- 1. 사진 + 물속 효과 (WebGL) ----------------
  useEffect(() => {
    const canvas = glCanvasRef.current;
    if (!canvas) return;
    const gl = canvas.getContext('webgl', { antialias: false, alpha: false, premultipliedAlpha: false });
    if (!gl) {
      setWebglFailed(true);
      return;
    }

    let disposed = false;
    let raf = 0;
    let program: WebGLProgram;
    try {
      program = gl.createProgram()!;
      gl.attachShader(program, compile(gl, gl.VERTEX_SHADER, VERT));
      gl.attachShader(program, compile(gl, gl.FRAGMENT_SHADER, FRAG));
      gl.linkProgram(program);
      if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error('link');
    } catch {
      setWebglFailed(true);
      return;
    }
    gl.useProgram(program);

    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    const aPos = gl.getAttribLocation(program, 'aPos');
    gl.enableVertexAttribArray(aPos);
    gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);

    const u = (n: string) => gl.getUniformLocation(program, n);
    const uRes = u('uRes'), uSize0 = u('uSize0'), uSize1 = u('uSize1');
    const uMix = u('uMix'), uTime = u('uTime');
    gl.uniform1i(u('uTex0'), 0);
    gl.uniform1i(u('uTex1'), 1);

    const makeTex = () => {
      const tex = gl.createTexture()!;
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([8, 40, 70, 255]));
      return tex;
    };
    // tex0 = 이전 사진, tex1 = 현재 사진 → uMix로 부드럽게 전환
    let tex0 = makeTex(), tex1 = makeTex();
    let size0: [number, number] = [9, 16], size1: [number, number] = [9, 16];
    let mixAmt = 1;
    let currentSrc = '';

    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);

    const setPhoto = (src: string) => {
      if (src === currentSrc) return;
      currentSrc = src;
      loadImage(src)
        .then((img) => {
          if (disposed || src !== currentSrc) return;
          // 현재 사진을 이전 사진 자리로 옮기고 새 사진을 올린 뒤 크로스페이드
          [tex0, tex1] = [tex1, tex0];
          size0 = size1;
          gl.bindTexture(gl.TEXTURE_2D, tex1);
          gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img);
          size1 = [img.naturalWidth, img.naturalHeight];
          mixAmt = 0;
        })
        .catch(() => {});
    };
    engineRef.current = { setPhoto };

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      canvas.width = Math.round(window.innerWidth * dpr);
      canvas.height = Math.round(window.innerHeight * dpr);
      gl.viewport(0, 0, canvas.width, canvas.height);
    };
    resize();
    window.addEventListener('resize', resize);

    const reduceMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    const start = performance.now();
    let last = 0;

    const draw = (now: number) => {
      raf = requestAnimationFrame(draw);
      if (now - last < 33) return; // 약 30fps로 제한해 배터리 절약
      const dt = last ? (now - last) / 1000 : 0;
      last = now;
      if (mixAmt < 1) mixAmt = Math.min(1, mixAmt + dt / 1.2);

      gl.uniform2f(uRes, canvas.width, canvas.height);
      gl.uniform2f(uSize0, size0[0], size0[1]);
      gl.uniform2f(uSize1, size1[0], size1[1]);
      gl.uniform1f(uMix, mixAmt);
      gl.uniform1f(uTime, reduceMotion ? 0 : (now - start) / 1000);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, tex0);
      gl.activeTexture(gl.TEXTURE1);
      gl.bindTexture(gl.TEXTURE_2D, tex1);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    };
    raf = requestAnimationFrame(draw);

    return () => {
      disposed = true;
      engineRef.current = null;
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }, []);

  useEffect(() => {
    engineRef.current?.setPhoto(photo);
  }, [photo, webglFailed]);

  // ---------------- 2. 떠오르는 물방울 ----------------
  useEffect(() => {
    const canvas = bubbleCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let w = 0, h = 0, dpr = 1;
    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);

    type Bubble = { x: number; y: number; r: number; speed: number; phase: number; wobble: number; alpha: number };
    const spawn = (anywhere: boolean, x?: number): Bubble => ({
      x: x ?? Math.random() * w,
      y: anywhere ? Math.random() * h : h + 10 + Math.random() * 40,
      r: Math.random() < 0.8 ? 1.5 + Math.random() * 3 : 4 + Math.random() * 5,
      speed: 0.35 + Math.random() * 0.9,
      phase: Math.random() * Math.PI * 2,
      wobble: 0.4 + Math.random() * 1.2,
      alpha: 0.35 + Math.random() * 0.4,
    });
    const bubbles: Bubble[] = Array.from({ length: 28 }, () => spawn(true));

    // 바닥 몇 군데에서 가늘게 올라오는 물방울 줄기
    const streams = [0.15, 0.82].map((fx) => ({ fx, timer: Math.random() * 60 }));

    const reduceMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    let raf = 0;
    let last = 0;
    let time = 0;

    const drawBubble = (b: Bubble) => {
      const g = ctx.createRadialGradient(b.x - b.r * 0.35, b.y - b.r * 0.35, b.r * 0.1, b.x, b.y, b.r);
      g.addColorStop(0, `rgba(255,255,255,${b.alpha * 0.9})`);
      g.addColorStop(0.45, `rgba(200,240,255,${b.alpha * 0.12})`);
      g.addColorStop(0.85, `rgba(220,245,255,${b.alpha * 0.35})`);
      g.addColorStop(1, `rgba(255,255,255,${b.alpha * 0.6})`);
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
      ctx.fillStyle = g;
      ctx.fill();
    };

    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      if (now - last < 33) return;
      last = now;
      time += 0.033;
      ctx.clearRect(0, 0, w, h);

      for (const s of streams) {
        s.timer -= 1;
        if (s.timer <= 0) {
          bubbles.push(spawn(false, s.fx * w + (Math.random() - 0.5) * 12));
          s.timer = 4 + Math.random() * 10;
        }
      }

      for (let i = bubbles.length - 1; i >= 0; i--) {
        const b = bubbles[i];
        if (!reduceMotion) {
          b.y -= b.speed * (0.6 + b.r * 0.12);
          b.x += Math.sin(time * 2 + b.phase) * b.wobble * 0.3;
        }
        if (b.y < -20) {
          if (bubbles.length > 40) bubbles.splice(i, 1);
          else Object.assign(b, spawn(false));
          continue;
        }
        drawBubble(b);
      }
    };
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden bg-[#031525]">
      {webglFailed ? (
        // WebGL을 못 쓰는 기기: 사진을 그대로 보여주고 천천히 움직이기만
        <img
          key={photo}
          src={photo}
          alt=""
          className="absolute inset-0 w-full h-full object-cover scale-105 animate-[pulse_14s_ease-in-out_infinite]"
          style={{ filter: 'brightness(0.8)' }}
        />
      ) : (
        <canvas ref={glCanvasRef} className="absolute inset-0 w-full h-full" />
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-sky-950/30 pointer-events-none" />
      <canvas ref={bubbleCanvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />
    </div>
  );
};
