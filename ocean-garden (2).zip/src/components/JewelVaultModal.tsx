import React from 'react';
import { CraftedGem, Language } from '../types';
import { THEME_CREATURES } from '../levels';
import { X, Award } from 'lucide-react';

interface JewelVaultModalProps {
  isOpen: boolean;
  onClose: () => void;
  gems: CraftedGem[];
  lang?: Language;
}

export const JewelVaultModal: React.FC<JewelVaultModalProps> = ({
  isOpen,
  onClose,
  gems,
  lang = 'ko',
}) => {
  if (!isOpen) return null;

  const totalCrafted = gems.reduce((sum, g) => sum + g.count, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-[fadeIn_0.2s_ease-out]">
      <div className="relative w-full max-w-lg max-h-[85vh] flex flex-col bg-slate-950 border border-sky-400/30 rounded-3xl shadow-[0_0_50px_rgba(56,189,248,0.25)] overflow-hidden">
        
        {/* Header */}
        <div className="relative p-5 pb-4 border-b border-sky-500/20 bg-gradient-to-r from-sky-950/40 via-slate-900/60 to-sky-950/40">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-sky-500/10 border border-sky-400/30 text-sky-400 text-xl">
                🦪
              </div>
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-1.5">
                  {lang === 'ko' ? '바다 진주 & 해양생물 도감' : 'Ocean Pearls & Marine Codex'}
                </h2>
                <p className="text-xs text-slate-400">
                  {lang === 'ko'
                    ? '시험관을 완성하여 구출한 아기 바다생물 컬렉션'
                    : 'Collection of rescued marine creatures & luminous pearls'}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Counter Banner */}
          <div className="mt-4 flex items-center justify-between px-4 py-2.5 rounded-2xl bg-sky-500/10 border border-sky-500/20">
            <div className="flex items-center gap-2 text-xs text-sky-200">
              <Award className="w-4 h-4 text-sky-400" />
              <span>{lang === 'ko' ? '누적 획득한 진주' : 'Total Luminous Pearls'}</span>
            </div>
            <span className="text-base font-extrabold text-amber-300 font-mono flex items-center gap-1">
              <span>{totalCrafted * 10}</span>
              <span>🦪</span>
            </span>
          </div>
        </div>

        {/* Scrollable Sea Creature Cards */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3 custom-scrollbar">
          {gems.map((gem) => {
            const def = THEME_CREATURES.aqua[gem.color];
            const isDiscovered = gem.count > 0;

            return (
              <div
                key={gem.color}
                className={`relative flex items-center gap-4 p-3.5 rounded-2xl border transition-all ${
                  isDiscovered
                    ? 'bg-slate-900/90 border-white/15 hover:border-sky-400/50 shadow-md'
                    : 'bg-slate-900/40 border-white/5 opacity-55'
                }`}
              >
                {/* Creature Orb Silhouette */}
                <div
                  className={`relative flex-shrink-0 w-12 h-12 rounded-2xl flex items-center justify-center text-2xl border-2 ${
                    isDiscovered
                      ? 'border-white/40 shadow-lg'
                      : 'border-white/10 grayscale'
                  }`}
                  style={{
                    background: isDiscovered
                      ? `linear-gradient(135deg, ${def?.glow || '#0284c7'}, #0284c7)`
                      : '#1e293b',
                  }}
                >
                  <span>{def?.symbol || '🫧'}</span>
                </div>

                {/* Details */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-white truncate">
                      {def?.name || gem.name}
                    </span>
                    <span className="text-[10px] text-sky-400 font-mono">
                      {def?.creatureName || gem.subName}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5 line-clamp-2">
                    {gem.description}
                  </p>
                </div>

                {/* Rescued Count */}
                <div className="flex flex-col items-end flex-shrink-0 pl-2">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold">
                    {lang === 'ko' ? '보호 수' : 'Saved'}
                  </span>
                  <span className="text-sm font-black text-amber-300 font-mono">
                    {gem.count}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
