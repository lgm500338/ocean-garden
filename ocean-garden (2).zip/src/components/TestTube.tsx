import React from 'react';
import { TubeData, ThemeType } from '../types';
import { CosmicOrb } from './CosmicOrb';

interface TestTubeProps {
  tube: TubeData;
  index: number;
  isSelected: boolean;
  onClick: () => void;
  theme: ThemeType;
  tubeCapacity?: number;
  canReceive?: boolean;
  isShaking?: boolean;
  isHintSource?: boolean;
  isHintTarget?: boolean;
  isMultiRow?: boolean;
}

export const TestTube: React.FC<TestTubeProps> = ({
  tube,
  index,
  isSelected,
  onClick,
  theme,
  tubeCapacity = 4,
  canReceive = false,
  isShaking = false,
  isHintSource = false,
  isHintTarget = false,
  isMultiRow = false,
}) => {
  // Responsive tube dimension calculation (2열 모드일 때 모바일/PC 모두 화면에 100% 쏙 들어오도록 최적화)
  const orbSize = isMultiRow ? 29 : 34; // px
  const tubeWidth = orbSize + 12; // 41px in 2-row, 46px in 1-row
  const tubeHeight = tubeCapacity * (orbSize + 2) + 16;

  // The top ball that is lifted when tube is selected
  const topBall = tube.balls.length > 0 ? tube.balls[tube.balls.length - 1] : null;
  // The balls remaining inside the tube (if selected, top ball is hovering above!)
  const insideBalls = isSelected ? tube.balls.slice(0, -1) : tube.balls;

  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      className={`relative p-0.5 sm:p-1 flex flex-col items-center cursor-pointer select-none bg-transparent border-0 outline-none focus:outline-none transition-transform duration-200 active:scale-95 ${
        isShaking ? 'animate-[bounce_0.35s_ease-in-out_infinite]' : ''
      }`}
      style={{ touchAction: 'manipulation' }}
      title={`Tube #${index + 1}`}
    >
      {/* 0. FLOATING HOVERING BALL ABOVE TUBE MOUTH (선택 시 시험관 입구 바로 위로 알맞게 솟아오름) */}
      {/* IMPORTANT: pointer-events-none so it NEVER blocks clicks on other tubes or background! */}
      {isSelected && topBall && (
        <div
          className={`absolute z-40 flex flex-col items-center pointer-events-none animate-[bounce_1.2s_ease-in-out_infinite] ${
            isMultiRow ? '-top-5 sm:-top-6' : '-top-6 sm:-top-7'
          }`}
        >
          {/* Water Aura Ring */}
          <div className="absolute -inset-1 rounded-full bg-cyan-400/40 blur-sm animate-pulse" />
          <CosmicOrb
            color={topBall.color}
            theme={theme}
            isFloating={true}
            size={orbSize}
          />
          {/* Downward Guidance Water Droplet */}
          <div className="w-1 h-1 rounded-full bg-cyan-300 mt-0.5 animate-ping" />
        </div>
      )}

      {/* 1. Wood/Golden Ocean Cork Cap (완성 시 우아하게 닫히는 황금 마개) */}
      <div
        className={`absolute top-0.5 z-30 transition-all duration-400 transform pointer-events-none ${
          tube.isSealed
            ? 'opacity-100 translate-y-2 scale-100'
            : '-translate-y-4 opacity-0 scale-90'
        }`}
      >
        <div className="relative flex flex-col items-center">
          <div
            className="bg-gradient-to-r from-amber-700 via-amber-600 to-amber-800 rounded-t-sm border border-amber-900 shadow-md flex items-center justify-around"
            style={{ width: `${tubeWidth - 4}px`, height: '10px' }}
          >
            <span className="w-0.5 h-1 bg-amber-950/60 rounded-full" />
            <span className="w-0.5 h-1 bg-amber-950/60 rounded-full" />
            <span className="w-0.5 h-1 bg-amber-950/60 rounded-full" />
          </div>
          <div
            className="bg-amber-800 rounded-b-sm shadow-inner"
            style={{ width: `${tubeWidth - 8}px`, height: '3px' }}
          />

          {/* Golden Ocean Star Emblem */}
          <div className="absolute -top-1.5 flex items-center justify-center w-4 h-4 rounded-full bg-gradient-to-tr from-yellow-500 via-amber-200 to-yellow-400 border border-amber-200 shadow-[0_0_10px_rgba(251,191,36,0.9)] animate-pulse">
            <span className="text-[9px] text-amber-950">★</span>
          </div>
        </div>
      </div>

      {/* 2. Glass Tube Container (투명 크리스탈 시험관) */}
      <div
        className={`relative flex flex-col-reverse items-center justify-start pb-1 pt-1 transition-all duration-200 rounded-b-[18px] rounded-t-[4px] overflow-visible ${
          isSelected
            ? 'border-cyan-300 shadow-[0_0_24px_rgba(6,182,212,0.9)] -translate-y-1'
            : canReceive
            ? 'border-emerald-300 shadow-[0_0_24px_rgba(52,211,153,0.9)] scale-105'
            : tube.isCompleted
            ? 'border-amber-300/90 shadow-[0_0_26px_rgba(251,191,36,0.6)]'
            : isHintSource
            ? 'border-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.7)]'
            : isHintTarget
            ? 'border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.7)]'
            : 'border-white/40 hover:border-white/75 shadow-[0_4px_16px_rgba(0,0,0,0.5)]'
        }`}
        style={{
          width: `${tubeWidth}px`,
          height: `${tubeHeight}px`,
          background: canReceive
            ? 'linear-gradient(180deg, rgba(52,211,153,0.3) 0%, rgba(14,116,144,0.35) 50%, rgba(8,47,73,0.75) 100%)'
            : tube.isCompleted
            ? 'linear-gradient(180deg, rgba(251,191,36,0.22) 0%, rgba(56,189,248,0.25) 50%, rgba(8,47,73,0.7) 100%)'
            : 'linear-gradient(180deg, rgba(56,189,248,0.18) 0%, rgba(14,116,144,0.26) 50%, rgba(8,47,73,0.6) 100%)',
          backdropFilter: 'blur(6px)',
          borderWidth: isSelected || canReceive || tube.isCompleted ? '2.5px' : '2px',
        }}
      >
        {/* Glass Lip */}
        <div className="absolute -top-1 inset-x-[-2px] h-1.5 rounded-full border-t border-b border-white/80 bg-white/30 shadow-sm" />

        {/* Specular Highlight */}
        <div className="absolute top-1.5 bottom-2.5 left-0.5 w-0.5 bg-gradient-to-b from-white/80 via-white/20 to-white/10 rounded-full pointer-events-none" />

        {/* Rising Celebration Sparkles & Living Aquarium Bubbles when completed */}
        {tube.isCompleted && (
          <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-b-[18px]">
            <div className="absolute inset-0 bg-gradient-to-t from-cyan-400/20 via-amber-300/10 to-transparent" />
            {/* Living Terrarium Micro Bubbles */}
            <div className="absolute bottom-2 left-2 w-1.5 h-1.5 rounded-full bg-cyan-200/80 animate-bottle-bubble" />
            <div className="absolute bottom-3 right-2.5 w-1 h-1 rounded-full bg-white/90 animate-bottle-bubble [animation-delay:0.7s]" />
            <div className="absolute bottom-1 left-4 w-1 h-1 rounded-full bg-amber-200/80 animate-bottle-bubble [animation-delay:1.4s]" />
            <div className="absolute bottom-4 right-4 w-1.5 h-1.5 rounded-full bg-cyan-100/90 animate-bottle-bubble [animation-delay:2.0s]" />
          </div>
        )}

        {/* Balls inside the tube (뚜껑 닫히면 살아 움직이는 바다생물 아쿠아리움으로 변신!) */}
        <div className="relative w-full flex flex-col-reverse items-center gap-0.5 z-10 pointer-events-none">
          {insideBalls.map((ball, bIdx) => (
            <div key={ball.id} className="relative">
              <CosmicOrb
                color={ball.color}
                theme={theme}
                isFloating={false}
                isSwimming={tube.isCompleted}
                swimDelay={bIdx * 0.35}
                size={orbSize}
              />
            </div>
          ))}
        </div>

        {/* Tube Bottom Rounded Reflection */}
        <div className="absolute bottom-0.5 inset-x-1.5 h-1.5 rounded-b-[16px] bg-white/20 blur-[0.5px] pointer-events-none" />
      </div>
    </button>
  );
};
