import React from 'react';
import { CraftedGem, ThemeType, Language } from '../types';
import { Sparkles, Trophy, ArrowRight, RotateCcw } from 'lucide-react';
import { GEM_DEFINITIONS } from '../levels';
import { getTranslation } from '../i18n';

interface VictoryModalProps {
  isOpen: boolean;
  levelNumber: number;
  moves: number;
  theme: ThemeType;
  lang?: Language;
  newGemsEarned: CraftedGem[];
  earnedPearls: number;
  onNextLevel: () => void;
  onRestartLevel: () => void;
  onOpenVault: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  isOpen,
  levelNumber,
  moves,
  lang = 'ko',
  newGemsEarned,
  earnedPearls,
  onNextLevel,
  onRestartLevel,
}) => {
  if (!isOpen) return null;
  const t = getTranslation(lang);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-[fadeIn_0.3s_ease-out]">
      <div className="relative w-full max-w-sm flex flex-col items-center bg-slate-950 border border-sky-400/40 rounded-3xl p-6 shadow-[0_0_60px_rgba(56,189,248,0.35)] text-center overflow-hidden">
        
        {/* Celebration Background Glow Rays */}
        <div className="absolute -top-16 w-64 h-64 rounded-full bg-gradient-to-b from-sky-400/25 via-emerald-500/15 to-transparent blur-3xl pointer-events-none" />

        {/* Ocean Shell / Trophy Icon */}
        <div className="relative mb-3 flex items-center justify-center w-16 h-16 rounded-3xl bg-gradient-to-tr from-sky-600 via-cyan-400 to-emerald-300 border-2 border-cyan-200 shadow-[0_0_24px_rgba(56,189,248,0.7)] animate-bounce">
          <Trophy className="w-8 h-8 text-sky-950 stroke-[2.5]" />
        </div>

        <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-1.5">
          {t.stageClear}
          <Sparkles className="w-5 h-5 text-amber-300 animate-spin" />
        </h2>
        <p className="text-xs text-sky-200/90 font-medium mt-0.5">
          {t.stageClearSub}
        </p>

        {/* Moves & Rating */}
        <div className="my-4 flex items-center gap-6 px-6 py-2 rounded-2xl bg-white/5 border border-white/10">
          <div className="flex flex-col items-center">
            <span className="text-[10px] text-slate-400 uppercase font-semibold">{t.moves}</span>
            <span className="text-lg font-black text-white font-mono">{moves}</span>
          </div>
          <div className="w-[1px] h-7 bg-white/15" />
          <div className="flex flex-col items-center">
            <span className="text-[10px] text-slate-400 uppercase font-semibold">
              {t.reward}
            </span>
            {earnedPearls > 0 ? (
              <span className="text-sm font-black text-amber-300 flex items-center gap-1">
                <span>+{earnedPearls}</span>
                <span>🦪</span>
              </span>
            ) : (
              <span className="text-[11px] font-bold text-slate-400">{t.rewardAlreadyEarned}</span>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="w-full mt-2 space-y-2">
          <button
            onClick={onNextLevel}
            className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-cyan-400 via-sky-400 to-emerald-400 hover:from-cyan-300 hover:to-emerald-300 text-slate-950 font-black text-sm shadow-[0_0_20px_rgba(56,189,248,0.5)] flex items-center justify-center gap-2 transition-transform active:scale-[0.98]"
          >
            <span>{t.nextLevel}</span>
            <ArrowRight className="w-4 h-4 stroke-[2.5]" />
          </button>

          <button
            onClick={onRestartLevel}
            className="w-full py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 hover:text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t.restart}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
