import { BallColor, CraftedGem, LevelConfig, ThemeType } from './types';
import { isPuzzleSolvable } from './solver';

// Deterministic PRNG using Mulberry32 algorithm
export function createPRNG(seed: number) {
  let s = (seed ^ 0xdeadbeef) + 0x1234567;
  return function () {
    s = Math.imul(s ^ (s >>> 15), s | 1);
    s ^= s + Math.imul(s ^ (s >>> 7), s | 61);
    return ((s ^ (s >>> 14)) >>> 0) / 4294967296;
  };
}

// Creature & Symbol metadata per color for each chapter
export const THEME_CREATURES: Record<
  ThemeType,
  Record<
    BallColor,
    {
      name: string;
      symbol: string; // Emoji / Icon symbol
      creatureName: string;
      gradient: string;
      glow: string;
      shadow: string;
    }
  >
> = {
  // 1. 바다 테마 (신비의 아쿠아리움 & 아기 바다생물)
  aqua: {
    amber: {
      name: '태양의 복어',
      symbol: '🐡',
      creatureName: '복어 (Puffer)',
      gradient: 'from-amber-200 via-orange-400 to-amber-700',
      glow: '#f59e0b',
      shadow: 'rgba(245, 158, 11, 0.7)',
    },
    ruby: {
      name: '불꽃 흰동가리',
      symbol: '🐠',
      creatureName: '클라운피시 (Clownfish)',
      gradient: 'from-rose-200 via-red-500 to-rose-900',
      glow: '#f43f5e',
      shadow: 'rgba(244, 63, 94, 0.7)',
    },
    violet: {
      name: '지혜의 보라문어',
      symbol: '🐙', // 구형 안드로이드 100% 호환 이모지
      creatureName: '문어 (Octopus)',
      gradient: 'from-purple-200 via-fuchsia-500 to-purple-900',
      glow: '#c084fc',
      shadow: 'rgba(192, 132, 252, 0.7)',
    },
    sapphire: {
      name: '심해의 돌고래',
      symbol: '🐬',
      creatureName: '돌고래 (Dolphin)',
      gradient: 'from-sky-200 via-blue-500 to-indigo-900',
      glow: '#38bdf8',
      shadow: 'rgba(56, 189, 248, 0.7)',
    },
    emerald: {
      name: '푸른 바다거북',
      symbol: '🐢',
      creatureName: '바다거북 (Turtle)',
      gradient: 'from-emerald-200 via-teal-400 to-emerald-800',
      glow: '#10b981',
      shadow: 'rgba(16, 185, 129, 0.7)',
    },
    cyan: {
      name: '푸른빛 바다상어',
      symbol: '🦈',
      creatureName: '상어 (Shark)',
      gradient: 'from-white via-cyan-300 to-sky-700',
      glow: '#67e8f9',
      shadow: 'rgba(103, 232, 249, 0.7)',
    },
    gold: {
      name: '전설의 황금고래',
      symbol: '🐳',
      creatureName: '황금고래 (Whale)',
      gradient: 'from-yellow-100 via-amber-300 to-yellow-600',
      glow: '#facc15',
      shadow: 'rgba(250, 204, 21, 0.8)',
    },
  },
  // 2. 우주 테마 (코스믹 오디세이 & 아기 외계인)
  cosmic: {
    violet: {
      name: '보라 아기외계인',
      symbol: '👾',
      creatureName: '아기외계인 (Alien)',
      gradient: 'from-purple-200 via-fuchsia-500 to-indigo-800',
      glow: '#c084fc',
      shadow: 'rgba(192, 132, 252, 0.7)',
    },
    sapphire: {
      name: '비행접시 UFO',
      symbol: '🛸',
      creatureName: 'UFO (Saucer)',
      gradient: 'from-cyan-200 via-blue-500 to-indigo-900',
      glow: '#60a5fa',
      shadow: 'rgba(96, 165, 250, 0.7)',
    },
    amber: {
      name: '우주 탐사선',
      symbol: '🚀',
      creatureName: '로켓 (Rocket)',
      gradient: 'from-amber-200 via-orange-500 to-amber-700',
      glow: '#fbbf24',
      shadow: 'rgba(251, 191, 36, 0.7)',
    },
    emerald: {
      name: '고리행성 토성',
      symbol: '🪐',
      creatureName: '행성 (Saturn)',
      gradient: 'from-emerald-200 via-teal-400 to-emerald-800',
      glow: '#34d399',
      shadow: 'rgba(52, 211, 153, 0.7)',
    },
    ruby: {
      name: '슈퍼노바 스타',
      symbol: '⭐',
      creatureName: '스타 (Star)',
      gradient: 'from-rose-200 via-red-500 to-rose-900',
      glow: '#fb7185',
      shadow: 'rgba(251, 113, 133, 0.7)',
    },
    cyan: {
      name: '은하수 초승달',
      symbol: '🌙',
      creatureName: '달 (Moon)',
      gradient: 'from-white via-cyan-300 to-sky-600',
      glow: '#67e8f9',
      shadow: 'rgba(103, 232, 249, 0.7)',
    },
    gold: {
      name: '코스믹 썬',
      symbol: '☀️',
      creatureName: '태양 (Sun)',
      gradient: 'from-yellow-100 via-amber-400 to-yellow-600',
      glow: '#facc15',
      shadow: 'rgba(250, 204, 21, 0.8)',
    },
  },
  // 3. 젤리 테마 (말랑 과즙 젤리)
  jelly: {
    ruby: {
      name: '딸기 젤리곰',
      symbol: '🍓',
      creatureName: '딸기 (Berry)',
      gradient: 'from-rose-200 via-red-400 to-pink-800',
      glow: '#f43f5e',
      shadow: 'rgba(244, 63, 94, 0.7)',
    },
    amber: {
      name: '오렌지 젤리',
      symbol: '🍊',
      creatureName: '오렌지 (Orange)',
      gradient: 'from-amber-200 via-orange-400 to-amber-700',
      glow: '#f59e0b',
      shadow: 'rgba(245, 158, 11, 0.7)',
    },
    emerald: {
      name: '청포도 젤리',
      symbol: '🍇',
      creatureName: '청포도 (Grape)',
      gradient: 'from-emerald-200 via-green-400 to-emerald-800',
      glow: '#10b981',
      shadow: 'rgba(16, 185, 129, 0.7)',
    },
    sapphire: {
      name: '블루베리 젤리',
      symbol: '🫐',
      creatureName: '블루베리 (Blueberry)',
      gradient: 'from-sky-200 via-blue-400 to-indigo-800',
      glow: '#3b82f6',
      shadow: 'rgba(59, 130, 246, 0.7)',
    },
    violet: {
      name: '달콤 포도 젤리',
      symbol: '🍬',
      creatureName: '캔디 (Candy)',
      gradient: 'from-purple-200 via-fuchsia-400 to-purple-800',
      glow: '#c084fc',
      shadow: 'rgba(192, 132, 252, 0.7)',
    },
    cyan: {
      name: '시원한 민트 젤리',
      symbol: '🍭',
      creatureName: '롤리팝 (Lollipop)',
      gradient: 'from-cyan-100 via-teal-300 to-cyan-700',
      glow: '#06b6d4',
      shadow: 'rgba(6, 182, 212, 0.7)',
    },
    gold: {
      name: '황금 꿀방울',
      symbol: '🍯',
      creatureName: '꿀방울 (Honey)',
      gradient: 'from-yellow-100 via-amber-300 to-amber-600',
      glow: '#eab308',
      shadow: 'rgba(234, 179, 8, 0.8)',
    },
  },
  // 4. 연금술 테마
  alchemy: {
    violet: {
      name: '아메지스트 룬',
      symbol: '✦',
      creatureName: '비전 (Arcane)',
      gradient: 'from-purple-300 via-purple-600 to-indigo-950',
      glow: '#c084fc',
      shadow: 'rgba(192, 132, 252, 0.7)',
    },
    sapphire: {
      name: '사파이어 룬',
      symbol: '▲',
      creatureName: '냉기 (Frost)',
      gradient: 'from-blue-300 via-blue-600 to-blue-950',
      glow: '#60a5fa',
      shadow: 'rgba(96, 165, 250, 0.7)',
    },
    amber: {
      name: '토파즈 룬',
      symbol: '☀',
      creatureName: '태양 (Solar)',
      gradient: 'from-amber-200 via-amber-500 to-amber-950',
      glow: '#fbbf24',
      shadow: 'rgba(251, 191, 36, 0.7)',
    },
    emerald: {
      name: '에메랄드 룬',
      symbol: '🜁',
      creatureName: '바람 (Wind)',
      gradient: 'from-emerald-200 via-emerald-500 to-emerald-950',
      glow: '#34d399',
      shadow: 'rgba(52, 211, 153, 0.7)',
    },
    ruby: {
      name: '루비 룬',
      symbol: '🜂',
      creatureName: '화염 (Fire)',
      gradient: 'from-rose-200 via-red-500 to-rose-950',
      glow: '#fb7185',
      shadow: 'rgba(251, 113, 133, 0.7)',
    },
    cyan: {
      name: '다이아 룬',
      symbol: '◈',
      creatureName: '프리즘 (Prism)',
      gradient: 'from-cyan-100 via-cyan-400 to-cyan-950',
      glow: '#67e8f9',
      shadow: 'rgba(103, 232, 249, 0.7)',
    },
    gold: {
      name: '현자의 돌',
      symbol: '☉',
      creatureName: '현자 (Sol)',
      gradient: 'from-yellow-100 via-amber-300 to-yellow-950',
      glow: '#facc15',
      shadow: 'rgba(250, 204, 21, 0.8)',
    },
  },
};

export const GEM_DEFINITIONS = THEME_CREATURES.aqua;

// -------------------------------------------------------------
// 무제한 솔버 보장 레벨 생성기 (Infinite Procedural Level Generator)
// -------------------------------------------------------------
const ALL_COLORS: BallColor[] = [
  'amber',
  'ruby',
  'violet',
  'sapphire',
  'emerald',
  'cyan',
  'gold',
];

// 같은 레벨은 한 번만 계산해서 재사용 (탭할 때마다 다시 계산하지 않도록)
const levelCache = new Map<number, LevelConfig>();

export function generateProceduralLevel(levelNum: number): LevelConfig {
  const cached = levelCache.get(levelNum);
  if (cached) return cached;
  const config = buildProceduralLevel(levelNum);
  levelCache.set(levelNum, config);
  return config;
}

function buildProceduralLevel(levelNum: number): LevelConfig {
  // 10레벨마다 챕터가 바뀌지만, 화면 테마는 바다(aqua)로 통일
  const chapter = Math.floor((levelNum - 1) / 10);
  const theme: ThemeType = 'aqua';

  // Progressive difficulty scaling up to 7 colors!
  let colorCount = 2;
  let emptyTubes = 1;

  if (levelNum === 1) {
    colorCount = 2;
    emptyTubes = 1; // 3 tubes (2 filled, 1 empty)
  } else if (levelNum <= 3) {
    colorCount = 3;
    emptyTubes = 2; // 5 tubes (3 filled, 2 empty)
  } else if (levelNum <= 6) {
    colorCount = 4;
    emptyTubes = 2; // 6 tubes (4 filled, 2 empty)
  } else if (levelNum <= 10) {
    colorCount = 5;
    emptyTubes = 2; // 7 tubes (5 filled, 2 empty)
  } else if (levelNum <= 18) {
    colorCount = 6;
    emptyTubes = 2; // 8 tubes (6 filled, 2 empty)
  } else {
    // Level 19+ introduces all 7 colors including rare gold whale!
    colorCount = 7;
    emptyTubes = 2; // 9 tubes (7 filled, 2 empty)
  }

  const selectedColors = ALL_COLORS.slice(0, colorCount);
  const capacity = 4;

  let bestTubes: BallColor[][] = [];
  let foundSolvable = false;

  // Deterministic seed PRNG generation verified with BFS solver
  for (let attempt = 0; attempt < 30; attempt++) {
    const rng = createPRNG(levelNum * 7919 + attempt * 1013);

    const solvedTubes: BallColor[][] = selectedColors.map((c) => [c, c, c, c]);
    for (let i = 0; i < emptyTubes; i++) {
      solvedTubes.push([]);
    }

    const shuffleSteps = Math.min(90, 14 + levelNum * 3);
    const candidateTubes: BallColor[][] = solvedTubes.map((t) => [...t]);

    let lastFrom = -1;
    let lastTo = -1;

    for (let step = 0; step < shuffleSteps; step++) {
      const validMoves: Array<{ from: number; to: number }> = [];

      for (let from = 0; from < candidateTubes.length; from++) {
        if (candidateTubes[from].length === 0) continue;
        for (let to = 0; to < candidateTubes.length; to++) {
          if (from === to) continue;
          if (candidateTubes[to].length >= capacity) continue;
          if (from === lastTo && to === lastFrom) continue;

          validMoves.push({ from, to });
        }
      }

      if (validMoves.length === 0) break;

      const chosen = validMoves[Math.floor(rng() * validMoves.length)];
      const ball = candidateTubes[chosen.from].pop()!;
      candidateTubes[chosen.to].push(ball);

      lastFrom = chosen.from;
      lastTo = chosen.to;
    }

    // Verify forward solvability using BFS solver!
    if (isPuzzleSolvable(candidateTubes, capacity, 2000)) {
      bestTubes = candidateTubes;
      foundSolvable = true;
      break;
    }
  }

  // Fallback if needed: deterministic light shuffle that is 100% solvable
  if (!foundSolvable) {
    const rng = createPRNG(levelNum * 7919);
    const fallbackTubes: BallColor[][] = selectedColors.map((c) => [c, c, c, c]);
    for (let i = 0; i < emptyTubes; i++) fallbackTubes.push([]);

    for (let s = 0; s < 12; s++) {
      const from = Math.floor(rng() * selectedColors.length);
      const to = selectedColors.length + Math.floor(rng() * emptyTubes);
      if (fallbackTubes[from].length > 0 && fallbackTubes[to].length < capacity) {
        fallbackTubes[to].push(fallbackTubes[from].pop()!);
      }
    }
    bestTubes = fallbackTubes;
  }

  const chapterNames = ['산호초 정원', '해초 숲', '진주 만', '심해 동굴', '고래의 바다'];
  const chapterNamesEn = ['Coral Garden', 'Kelp Forest', 'Pearl Bay', 'Deep Cave', 'Whale Sea'];
  const chapterIdx = chapter % chapterNames.length;

  return {
    levelNumber: levelNum,
    tubeCapacity: capacity,
    theme,
    title: `${chapterNames[chapterIdx]} · 스테이지 ${levelNum}`,
    titleEn: `${chapterNamesEn[chapterIdx]} · Stage ${levelNum}`,
    tubes: bestTubes,
  };
}

// Initial Hand-Crafted Tutorial Levels (Levels 1-3)
export const INITIAL_LEVELS: LevelConfig[] = [
  {
    levelNumber: 1,
    tubeCapacity: 4,
    theme: 'aqua',
    title: '산호초 정원 (입문)',
    titleEn: 'Coral Garden (Intro)',
    tubes: [
      ['amber', 'ruby', 'amber', 'ruby'],
      ['ruby', 'amber', 'ruby', 'amber'],
      [],
    ],
  },
  {
    levelNumber: 2,
    tubeCapacity: 4,
    theme: 'aqua',
    title: '산호초 정원 · 스테이지 2',
    titleEn: 'Coral Garden · Stage 2',
    tubes: [
      ['violet', 'amber', 'violet', 'ruby'],
      ['amber', 'ruby', 'violet', 'ruby'],
      ['ruby', 'amber', 'amber', 'violet'],
      [],
      [],
    ],
  },
  {
    levelNumber: 3,
    tubeCapacity: 4,
    theme: 'aqua',
    title: '산호초 정원 · 스테이지 3',
    titleEn: 'Coral Garden · Stage 3',
    tubes: [
      ['emerald', 'sapphire', 'ruby', 'emerald'],
      ['sapphire', 'ruby', 'emerald', 'sapphire'],
      ['ruby', 'emerald', 'sapphire', 'ruby'],
      [],
      [],
    ],
  },
];

export const INITIAL_GEMS: CraftedGem[] = ALL_COLORS.map((c) => ({
  color: c,
  name: THEME_CREATURES.aqua[c].name,
  subName: THEME_CREATURES.aqua[c].creatureName,
  description: `${THEME_CREATURES.aqua[c].symbol} 정제된 마법의 생명 원석`,
  count: 0,
  unlockedAt: '',
  rarity: c === 'gold' ? 'Legendary' : c === 'cyan' ? 'Epic' : 'Rare',
}));
