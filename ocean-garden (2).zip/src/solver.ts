import { TubeData, HintMove } from './types';

export function findSmartHint(
  tubes: TubeData[],
  capacity: number = 4
): HintMove | null {
  // Priority 1: Moves that immediately COMPLETE a tube (3 balls + 1 matching ball = 4)
  for (let from = 0; from < tubes.length; from++) {
    const src = tubes[from];
    if (src.isCompleted || src.balls.length === 0) continue;
    const topBall = src.balls[src.balls.length - 1];

    for (let to = 0; to < tubes.length; to++) {
      if (from === to) continue;
      const tgt = tubes[to];
      if (tgt.isCompleted) continue;

      if (
        tgt.balls.length === capacity - 1 &&
        tgt.balls.every((b) => b.color === topBall.color)
      ) {
        return {
          fromTubeIdx: from,
          toTubeIdx: to,
          reason: '이 시험관을 완성하여 다이아몬드로 정제하세요!',
        };
      }
    }
  }

  // Priority 2: Moves that consolidate colors onto an existing matching color
  for (let from = 0; from < tubes.length; from++) {
    const src = tubes[from];
    if (src.isCompleted || src.balls.length === 0) continue;
    // Don't move if source is already pure single-color
    const isSrcPure = src.balls.every((b) => b.color === src.balls[0].color);
    if (isSrcPure && src.balls.length === capacity) continue;

    const topBall = src.balls[src.balls.length - 1];

    for (let to = 0; to < tubes.length; to++) {
      if (from === to) continue;
      const tgt = tubes[to];
      if (tgt.isCompleted || tgt.balls.length >= capacity || tgt.balls.length === 0) continue;

      const tgtTop = tgt.balls[tgt.balls.length - 1];
      if (tgtTop.color === topBall.color) {
        return {
          fromTubeIdx: from,
          toTubeIdx: to,
          reason: '같은 색상의 구슬을 모아 튜브를 비워보세요.',
        };
      }
    }
  }

  // Priority 3: Move to an empty tube IF it unblocks a different color underneath
  for (let from = 0; from < tubes.length; from++) {
    const src = tubes[from];
    if (src.isCompleted || src.balls.length <= 1) continue;
    // Only move if balls under it have a DIFFERENT color
    const isSrcPure = src.balls.every((b) => b.color === src.balls[0].color);
    if (isSrcPure) continue;

    for (let to = 0; to < tubes.length; to++) {
      if (from === to) continue;
      const tgt = tubes[to];
      if (tgt.isCompleted || tgt.balls.length > 0) continue; // Must be empty

      return {
        fromTubeIdx: from,
        toTubeIdx: to,
        reason: '빈 시험관으로 구슬을 옮겨 아래에 갇힌 구슬을 꺼내세요.',
      };
    }
  }

  return null;
}

/**
 * 100% Guaranteed BFS Solvability Verifier
 * Explores possible state transitions and returns true if and only if
 * the puzzle can reach a fully sorted winning state.
 */
export function isPuzzleSolvable(
  tubes: string[][],
  capacity: number = 4,
  maxExplored: number = 3000
): boolean {
  const isSolved = (state: string[][]) =>
    state.every((t) => t.length === 0 || (t.length === capacity && t.every((b) => b === t[0])));

  if (isSolved(tubes)) return true;

  const hashState = (state: string[][]) =>
    state.map((t) => t.join(',')).sort().join('|');

  const visited = new Set<string>();
  const queue: string[][][] = [tubes];
  visited.add(hashState(tubes));

  let count = 0;
  while (queue.length > 0 && count < maxExplored) {
    count++;
    const current = queue.shift()!;
    if (isSolved(current)) return true;

    for (let f = 0; f < current.length; f++) {
      if (current[f].length === 0) continue;
      const topBall = current[f][current[f].length - 1];

      for (let t = 0; t < current.length; t++) {
        if (f === t) continue;
        if (current[t].length >= capacity) continue;

        const targetEmpty = current[t].length === 0;
        const targetSameColor =
          current[t].length > 0 && current[t][current[t].length - 1] === topBall;

        if (targetEmpty || targetSameColor) {
          const next = current.map((tube, idx) => {
            if (idx === f) return tube.slice(0, -1);
            if (idx === t) return [...tube, topBall];
            return tube;
          });

          const hash = hashState(next);
          if (!visited.has(hash)) {
            visited.add(hash);
            if (isSolved(next)) return true;
            queue.push(next);
          }
        }
      }
    }
  }

  return false;
}

/**
 * 정답 경로 기반 힌트: 현재 상태에서 BFS로 풀이를 찾아 그 첫 수를 알려준다.
 * 탐색 한도 안에서 풀이를 못 찾으면 null을 반환한다(그때는 findSmartHint로 대체).
 */
export function findSolverHint(
  tubes: TubeData[],
  capacity: number = 4,
  maxExplored: number = 30000
): HintMove | null {
  const start: string[][] = tubes.map((t) => t.balls.map((b) => b.color));

  const isPureFull = (t: string[]) => t.length === capacity && t.every((b) => b === t[0]);
  const isSolved = (state: string[][]) => state.every((t) => t.length === 0 || isPureFull(t));
  const hashState = (state: string[][]) => state.map((t) => t.join(',')).sort().join('|');

  if (isSolved(start)) return null;

  type Node = { state: string[][]; first: { from: number; to: number } | null };
  const visited = new Set<string>([hashState(start)]);
  const queue: Node[] = [{ state: start, first: null }];
  let head = 0;

  while (head < queue.length && head < maxExplored) {
    const { state, first } = queue[head++];

    for (let f = 0; f < state.length; f++) {
      const src = state[f];
      if (src.length === 0 || isPureFull(src)) continue;
      const top = src[src.length - 1];
      const srcPure = src.every((b) => b === top);

      for (let t = 0; t < state.length; t++) {
        if (f === t) continue;
        const tgt = state[t];
        if (tgt.length >= capacity) continue;
        if (tgt.length > 0 && tgt[tgt.length - 1] !== top) continue;
        // 한 색만 든 시험관을 빈 시험관으로 통째로 옮기는 건 의미 없는 수
        if (tgt.length === 0 && srcPure) continue;

        const next = state.map((tube, idx) => {
          if (idx === f) return tube.slice(0, -1);
          if (idx === t) return [...tube, top];
          return tube;
        });
        const h = hashState(next);
        if (visited.has(h)) continue;
        visited.add(h);

        const move = first ?? { from: f, to: t };
        if (isSolved(next)) {
          return { fromTubeIdx: move.from, toTubeIdx: move.to, reason: '' };
        }
        queue.push({ state: next, first: move });
      }
    }
  }
  return null;
}
