export type BallColor = 
  | 'violet'
  | 'sapphire'
  | 'amber'
  | 'emerald'
  | 'ruby'
  | 'cyan'
  | 'gold';

export type Language = 'ko' | 'en';

export interface Ball {
  id: string;
  color: BallColor;
}

export type ThemeType = 'aqua' | 'cosmic' | 'jelly' | 'alchemy';

export interface TubeData {
  id: number;
  balls: Ball[];
  isCompleted: boolean;
  isRefining: boolean;
  isSealed: boolean;
}

export interface LevelConfig {
  levelNumber: number;
  tubeCapacity: number;
  tubes: BallColor[][];
  theme: ThemeType;
  title: string;
  titleEn?: string;
}

export interface CraftedGem {
  color: BallColor;
  name: string;
  subName: string;
  description: string;
  count: number;
  unlockedAt: string;
  rarity: 'Common' | 'Rare' | 'Epic' | 'Legendary';
}

export interface GameHistoryState {
  tubes: TubeData[];
  moves: number;
}

export interface HintMove {
  fromTubeIdx: number;
  toTubeIdx: number;
  reason: string;
}
